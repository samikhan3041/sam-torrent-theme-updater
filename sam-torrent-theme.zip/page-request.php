<?php
/**
 * Template Name: Movie Request
 * @package SamTorrentHub
 */
get_header(); 
?>

<div class="static-page form-page">
    <h1 class="page-title"><?php the_title(); ?></h1>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="entry-content" style="margin-bottom: 2rem;">
            <?php the_content(); ?>
        </div>
    <?php endwhile; endif; ?>

    <?php 
    // Display feedback messages based on the URL parameter
    if ( isset( $_GET['status'] ) ) {
        if ( $_GET['status'] === 'success' ) {
            echo '<div class="flash success">Thank you for your request! We will look into it.</div>';
        } else {
            echo '<div class="flash error">An error occurred. Please try again.</div>';
        }
    }
    ?>

    <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" class="contact-form">
        
        <input type="hidden" name="action" value="sam_request_form">
        <input type="hidden" name="redirect_url" value="<?php echo esc_url( get_permalink() ); ?>">
        <?php wp_nonce_field( 'submit_request_form_action', 'request_form_nonce' ); ?>
        
        <!-- Honeypot -->
        <p style="display:none !important;"><label for="user_nickname">Nickname</label><input type="text" id="user_nickname" name="user_nickname" tabindex="-1" autocomplete="off"></p>

        <div class="form-group">
            <label for="movie_title">Title (Movie or TV Show)</label>
            <input type="text" id="movie_title" name="movie_title" required>
        </div>
        <div class="form-group">
            <label for="year">Year of Release</label>
            <input type="number" id="year" name="year" min="1900" max="2030" placeholder="e.g., 2023">
        </div>
        <div class="form-group">
            <label for="notes">Additional Notes (Optional)</label>
            <textarea id="notes" name="notes" rows="4" placeholder="e.g., Specific season, quality, etc."></textarea>
        </div>
        <button type="submit" name="submit_request_form" class="form-button">Submit Request</button>
    </form>
</div>

<?php get_footer(); ?>