<?php
/**
 * The template for displaying Movie archive pages.
 * @package SamTorrentHub
 */
get_header();

$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
$page_title = 'Movies'; $base_pagination_url = home_url('/movies/'); $api_params = [];
$archive_type = get_query_var('movie_archive_type'); $archive_slug = get_query_var('archive_slug');

if ($archive_type === 'recent') { $page_title = 'Recently Added Movies'; $base_pagination_url = home_url('/movies/recent/'); $api_params = ['sort_by' => 'date_added', 'page' => $paged];
} elseif ($archive_type === 'trending') { $page_title = 'Trending Movies'; $base_pagination_url = home_url('/movies/trending/'); $api_params = ['sort_by' => 'download_count', 'page' => $paged];
} elseif ($archive_type === 'top-rated') { $page_title = 'Top Rated Movies'; $base_pagination_url = home_url('/movies/top-rated/'); $api_params = ['sort_by' => 'rating', 'minimum_rating' => 8.5, 'page' => $paged];
} elseif ($archive_type === 'year' && $archive_slug) { $page_title = 'Movies from ' . esc_html($archive_slug); $base_pagination_url = home_url('/movies/year/' . $archive_slug . '/'); $api_params = ['query_term' => $archive_slug, 'sort_by' => 'date_added', 'page' => $paged];
}
$data = get_filtered_movies_yts($api_params);
$movies = $data['items'] ?? [];
?>

<h1 class="page-title"><?php echo esc_html($page_title); ?></h1>

<?php if ( ! empty( $movies ) ) : ?>
    <div class="movie-grid">
        <?php foreach ( $movies as $movie ) :
            $item_url = home_url('/movie/' . $movie['id'] . '/' . sanitize_title($movie['title']));
            ?>
            <a href="<?php echo esc_url($item_url); ?>" class="movie-card">
                <img src="<?php echo esc_url($movie['medium_cover_image']); ?>" alt="<?php echo esc_attr($movie['title_long']); ?>">
                <div class="movie-card-info">
                    <h3 class="movie-card-title"><?php echo esc_html($movie['title_long']); ?></h3>
                    <p class="movie-card-year"><?php echo esc_html($movie['year']); ?></p>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
    <?php sam_theme_pagination($paged, $data['total_pages'], $base_pagination_url); ?>
    <?php sam_display_ad('ad_archive'); ?>
<?php else : ?>
    <p>No movies found matching these criteria.</p>
<?php endif; ?>

<?php get_footer(); ?>