<?php
/**
 * The template for displaying Actor archive pages (API-Driven with Caching).
 * This version fetches data live from the API and caches the results for 30 days.
 * It does NOT import any posts in the background.
 *
 * @package SamTorrentHub
 */

get_header();

global $sam_theme_options;
$tmdb_api_key = $sam_theme_options['tmdb_api_key'] ?? '';

// Immediately stop if the API key is missing.
if (empty($tmdb_api_key)) {
    echo '<h1 class="page-title">Configuration Needed</h1>';
    echo '<p style="text-align:center;">Please set your TMDB API Key in Theme Options to display actor pages.</p>';
    get_footer();
    return;
}

$actor_term = get_queried_object();
$actor_name = $actor_term->name;
$all_media = []; // Initialize an empty array for media.

// --- THE NEW CACHING LOGIC ---

// 1. Create a unique key for this actor's filmography cache.
$cache_key = 'actor_filmography_' . $actor_term->slug;

// 2. Try to get the data from the cache first.
$cached_media = get_transient($cache_key);

if (false !== $cached_media) {
    // If we found cached data, use it!
    $all_media = $cached_media;
} else {
    // If no cache, fetch fresh data from the API.
    
    // Find the actor's TMDB ID (this is also cached).
    $actor_tmdb_id = get_transient('actor_tmdb_id_' . $actor_term->slug);
    if (false === $actor_tmdb_id) {
        $search_url = "https://api.themoviedb.org/3/search/person?api_key={$tmdb_api_key}&query=" . urlencode($actor_name);
        $response = wp_remote_get($search_url);
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $actor_tmdb_id = $data['results'][0]['id'] ?? 0;
            set_transient('actor_tmdb_id_' . $actor_term->slug, $actor_tmdb_id, WEEK_IN_SECONDS);
        }
    }

    // Fetch the full filmography from the API.
    if ($actor_tmdb_id) {
        $credits_url = "https://api.themoviedb.org/3/person/{$actor_tmdb_id}/combined_credits?api_key={$tmdb_api_key}";
        $response = wp_remote_get($credits_url);
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            $all_media = $data['cast'] ?? [];
            
            // 3. Save the fresh API results into our cache for 30 days.
            set_transient($cache_key, $all_media, 30 * DAY_IN_SECONDS);
        }
    }
}
?>

<h1 class="page-title">Media Featuring <?php echo esc_html($actor_name); ?></h1>

<?php if ( !empty($all_media) ) : ?>
    <div class="movie-grid">
        <?php foreach ( $all_media as $media ) :
            if (empty($media['poster_path'])) continue; // Skip items without a poster
            $type = $media['media_type'] ?? 'movie';
            $id = $media['id'] ?? 0;
            $title = ($type === 'tv') ? ($media['name'] ?? 'Untitled') : ($media['title'] ?? 'Untitled');
            $year = substr($media['release_date'] ?? $media['first_air_date'] ?? '', 0, 4);
            // This link will trigger the on-demand creation if the post doesn't exist locally.
            $item_url = home_url("/{$type}/{$id}/" . sanitize_title($title) . "/");
        ?>
            <a href="<?php echo esc_url($item_url); ?>" class="movie-card">
                <img src="<?php echo get_tmdb_image_url($media['poster_path']); ?>" alt="<?php echo esc_attr($title); ?>">
                <div class="movie-card-info">
                    <h3 class="movie-card-title"><?php echo esc_html($title); ?></h3>
                    <p class="movie-card-year"><?php echo esc_html($year); ?></p>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
    <?php sam_display_ad('ad_archive'); ?>
<?php else : ?>
    <p>No media could be found for <?php echo esc_html($actor_name); ?>.</p>
<?php endif; ?>

<?php
get_footer();
?>