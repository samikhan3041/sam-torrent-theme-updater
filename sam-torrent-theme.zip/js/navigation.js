jQuery(document).ready(function($) {
    var menuToggle = $('.menu-toggle');
    var mainNav = $('.header-nav');

    if (menuToggle.length && mainNav.length) {
        menuToggle.on('click', function() {
            $(this).toggleClass('is-active');
            mainNav.toggleClass('is-toggled');
        });
    }
});