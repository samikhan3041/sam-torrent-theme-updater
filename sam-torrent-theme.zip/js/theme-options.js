jQuery(document).ready(function($) {
    // Initialize the WordPress color picker on our fields
    $('.sam-color-picker').wpColorPicker();
});