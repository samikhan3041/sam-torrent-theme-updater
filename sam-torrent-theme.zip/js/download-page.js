document.addEventListener('DOMContentLoaded', function() {
    // Get data passed from WordPress
    const timerDuration = parseInt(download_data.timer, 10);
    const magnetLink = download_data.magnet;

    const timerContainer = document.getElementById('download-timer-container');
    const linkContainer = document.getElementById('download-link-container');
    const countdownDisplay = document.getElementById('timer-countdown');
    const copyButton = document.getElementById('copy-download-button');
    const magnetField = document.getElementById('magnet_link_field');

    if (!linkContainer) return; // Exit if elements not found

    const showLink = () => {
        if (timerContainer) timerContainer.style.display = 'none';
        linkContainer.style.display = 'block';
    };

    if (timerDuration > 0) {
        let timer = timerDuration;
        countdownDisplay.textContent = timer;
        const interval = setInterval(() => {
            timer--;
            countdownDisplay.textContent = timer;
            if (timer <= 0) {
                clearInterval(interval);
                showLink();
            }
        }, 1000);
    } else {
        showLink();
    }

    copyButton.addEventListener('click', () => {
        magnetField.select();
        document.execCommand('copy');
        copyButton.textContent = 'Copied!';
        setTimeout(() => {
            copyButton.textContent = 'Copy to Clipboard';
        }, 2000);
    });
});