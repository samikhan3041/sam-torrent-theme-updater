/**
 * Main JavaScript for Sam Torrent Theme
 *
 * Handles client-side interactions, like copying magnet links.
 * UPDATED: Now specifically targets BUTTON elements to avoid interfering with links.
 */
document.addEventListener('DOMContentLoaded', function () {

    /**
     * Handles copying magnet links to the clipboard.
     * Provides visual feedback to the user on success.
     */
    // This selector is now more specific: it only looks for <button> elements.
    document.querySelectorAll('button.copy-magnet-button').forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault(); // This will now only affect the copy buttons, not links.
            const magnetLink = button.dataset.magnet;

            if (!magnetLink) {
                console.error('No magnet link found on this button.');
                alert('Error: No magnet link found.');
                return;
            }

            const copyToClipboard = (text) => {
                if (navigator.clipboard && window.isSecureContext) {
                    return navigator.clipboard.writeText(text);
                } else {
                    return new Promise((resolve, reject) => {
                        const textArea = document.createElement('textarea');
                        textArea.value = text;
                        textArea.style.position = 'fixed';
                        textArea.style.top = '-9999px';
                        textArea.style.left = '-9999px';
                        document.body.appendChild(textArea);
                        textArea.focus();
                        textArea.select();
                        try {
                            document.execCommand('copy');
                            document.body.removeChild(textArea);
                            resolve();
                        } catch (err) {
                            document.body.removeChild(textArea);
                            reject(err);
                        }
                    });
                }
            };
            
            copyToClipboard(magnetLink).then(() => {
                const originalContent = button.innerHTML;
                button.classList.add('copied');
                button.innerHTML = "Copied!";
                setTimeout(() => {
                    button.innerHTML = originalContent;
                    button.classList.remove('copied');
                }, 1500);
            }).catch(err => {
                console.error('Failed to copy magnet link: ', err);
                alert('Could not copy link. Please try again or copy manually.');
            });
        });
    });

});