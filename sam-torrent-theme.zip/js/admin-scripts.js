jQuery(document).ready(function($) {

    // --- Part 1: Searching for a movie/show ---
    $('#sam-tmdb-fetch-button').on('click', function() {
        var query = $('#sam-tmdb-query').val();
        var type = $('#sam-tmdb-type').val();
        var resultsContainer = $('#sam-tmdb-results');
        var fetchButton = $(this);

        if (!query) {
            alert('Please enter a title to search for.');
            return;
        }

        fetchButton.text('Fetching...').prop('disabled', true);
        resultsContainer.html('<p>Searching...</p>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'sam_search_tmdb', nonce: sam_admin_vars.nonce, query: query, type: type },
            success: function(response) {
                fetchButton.text('Fetch Details').prop('disabled', false);
                if (response.success && response.data.length > 0) {
                    var output = '<ul>';
                    response.data.forEach(function(item) {
                        output += '<li>';
                        output += '<button class="button sam-select-item" data-id="' + item.id + '">' + item.title + ' (' + item.year + ')</button>';
                        output += '</li>';
                    });
                    output += '</ul>';
                    resultsContainer.html(output);
                } else {
                    resultsContainer.html('<p>No results found.</p>');
                }
            },
            error: function() {
                fetchButton.text('Fetch Details').prop('disabled', false);
                resultsContainer.html('<p>An error occurred. Please try again.</p>');
            }
        });
    });

    // --- Part 2: Selecting a result and populating fields ---
    $('#sam-tmdb-results').on('click', '.sam-select-item', function() {
        var tmdbId = $(this).data('id');
        var type = $('#sam-tmdb-type').val();
        var resultsContainer = $('#sam-tmdb-results');

        resultsContainer.html('<p>Populating fields, please wait...</p>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'sam_get_tmdb_details', nonce: sam_admin_vars.nonce, tmdb_id: tmdbId, post_id: sam_admin_vars.post_id, type: type },
                        success: function(response) {
                if (response.success) {
                    var data = response.data;
                    
                    // Set post title
                    $('#title').val(data.title).focus(); 

                    // Populate our new native meta fields by their ID
                    $('#sam_year').val(data.year);
                    $('#sam_rating').val(data.rating);
                    $('#sam_backdrop_path').val(data.backdrop_path);
                    $('#sam_tmdb_id').val(data.tmdb_id);
                    $('#sam_synopsis').val(data.overview);
                    $('#sam_genres_text').val(data.genres.join(', '));

                    // Clear fields that are not relevant for this fetch
                    $('#sam_torrent_titles').val('');
                    $('#sam_magnet_links').val('');
                    $('#sam_torrents_data').val('');

                    // Clear the main editor to avoid confusion
                    if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content')) {
                        tinyMCE.get('content').setContent('');
                    } else {
                        $('#content').val('');
                    }

                    // Set the featured image
                    if (data.attachment_id) {
                        WPSetAsThumbnail(data.attachment_id, 'set-post-thumbnail');
                    }

                    resultsContainer.html('<p style="color: green;">Fields populated successfully!</p>');

                } else {
                    resultsContainer.html('<p style="color: red;">Error: ' + response.data + '</p>');
                }
            },
            error: function() {
                 resultsContainer.html('<p style="color: red;">A critical error occurred.</p>');
            }
        });
    });
});