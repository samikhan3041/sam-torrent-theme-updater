<?php if ( is_active_sidebar( 'sidebar-movie' ) ) : ?>
<aside id="secondary-movie" class="widget-area movie-sidebar">
	<?php dynamic_sidebar( 'sidebar-movie' ); ?>
</aside>
<?php endif; ?>