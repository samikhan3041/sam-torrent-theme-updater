<?php
/**
 * The template for the intermediate download page.
 * @package SamTorrentHub
 */

global $sam_theme_options;
$post_id    = get_query_var('download_post_id');
$link_index = get_query_var('download_link_index');
$post_type  = get_post_type($post_id);

$magnet_link = '';
$link_title  = '';

if ($post_type === 'movie') {
    // For movies, the title and size are already combined in the meta field.
    $magnet_links   = explode("\n", trim(get_post_meta($post_id, '_sam_magnet_links', true)));
    $torrent_titles = explode("\n", trim(get_post_meta($post_id, '_sam_torrent_titles', true)));
    if (isset($magnet_links[$link_index])) {
        $magnet_link = trim($magnet_links[$link_index]);
        $link_title  = trim($torrent_titles[$link_index] ?? 'Download Link');
    }
} elseif ($post_type === 'tv_show') {
    // --- THIS IS THE CORRECTED LOGIC FOR TV SHOWS ---
    // Re-parses the torrent data to build a fully contextual title.
    $raw_data  = get_post_meta($post_id, '_sam_torrents_data', true);
    $lines     = explode("\n", trim($raw_data));
    $all_links = [];
    foreach ($lines as $line) {
        $parts = explode('|', $line, 4);
        if (count($parts) === 4) {
            $episode_info = trim($parts[0]); // e.g., "S01E02" or "S01PACK"
            $quality      = trim($parts[1]); // e.g., "720p" or "Full Season"
            $size         = trim($parts[2]); // e.g., "450 MB"

            // Construct the new, more descriptive title.
            $full_context_title = "{$episode_info}: {$quality}";
            if (!empty($size)) {
                $full_context_title .= " ({$size})";
            }
            
            $all_links[] = ['magnet' => trim($parts[3]), 'title' => $full_context_title];
        }
    }
    // Now get the correct link by its index.
    if (isset($all_links[$link_index])) {
        $magnet_link = $all_links[$link_index]['magnet'];
        $link_title  = $all_links[$link_index]['title'];
    }
    // --- END OF CORRECTION ---
}

// Get timer value from theme options.
$timer = $sam_theme_options['link_delay_timer'] ?? 5;

get_header(); ?>

<div class="static-page" style="text-align: center; max-width: 600px;">
    <h1 class="page-title"><?php echo get_the_title($post_id); ?></h1>
    
    <?php if (has_post_thumbnail($post_id)): ?>
        <img src="<?php echo get_the_post_thumbnail_url($post_id, 'medium'); ?>" style="width: 200px; height: auto; border-radius: 8px; margin-bottom: 2rem;">
    <?php endif; ?>

    <p style="font-size: 1.2rem;">You are downloading the version: <strong><?php echo esc_html($link_title); ?></strong></p>

    <?php sam_display_ad('ad_download'); ?>

    <div id="download-timer-container">
        <p style="font-size: 1.5rem;">Your link is being processed...</p>
        <p id="timer-countdown" style="font-size: 3rem; font-weight: bold; color: var(--accent-color);"></p>
    </div>

    <div id="download-link-container" style="display: none;">
        <div class="form-group">
            <label for="magnet_link_field">Your Magnet Link</label>
            <input type="text" id="magnet_link_field" value="<?php echo esc_attr($magnet_link); ?>" readonly>
        </div>
        <button id="copy-download-button" class="form-button" style="margin-top: 1rem;">Copy to Clipboard</button>
    </div>

</div>

<?php 
// Enqueue script and pass data.
wp_enqueue_script('sam-download-page-script', get_template_directory_uri() . '/js/download-page.js', [], '1.0.0', true);
wp_localize_script('sam-download-page-script', 'download_data', ['timer' => $timer, 'magnet' => $magnet_link]);

get_footer(); 
?>