<?php
/**
 * The main template file
 *
 * @package SamTorrentHub
 */

get_header(); // This will load the WordPress header.
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <h1>Welcome to the Sam Torrent Hub Theme</h1>
        <p>We are setting up the templates.</p>
    </div>
</main>

<?php
get_footer(); // This will load the WordPress footer.
?>