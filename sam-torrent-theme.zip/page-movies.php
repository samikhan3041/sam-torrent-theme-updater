<?php
/**
 * Template Name: Movies Hub
 * @package SamTorrentHub
 */

get_header();

/**
 * Helper function to render a movie hub section.
 */
function sam_render_movie_hub_section($title, $browse_more_link, $api_params) {
    $data = get_filtered_movies_yts($api_params);
    $movies = $data['items'] ?? [];

    if (empty($movies)) { return; }
    $movies_to_display = array_slice($movies, 0, 6);
    ?>
    <section class="hub-section">
        <header class="hub-section-header">
            <h2 class="hub-section-title"><?php echo esc_html($title); ?></h2>
            <a href="<?php echo esc_url($browse_more_link); ?>" class="browse-more-button">Browse More</a>
        </header>
        <div class="movie-grid">
            <?php foreach ($movies_to_display as $movie) :
                $item_url = home_url('/movie/' . $movie['id'] . '/' . sanitize_title($movie['title']));
                ?>
                <a href="<?php echo esc_url($item_url); ?>" class="movie-card">
                    <img src="<?php echo esc_url($movie['medium_cover_image']); ?>" alt="<?php echo esc_attr($movie['title_long']); ?>">
                    <div class="movie-card-info">
                        <h3 class="movie-card-title"><?php echo esc_html($movie['title_long']); ?></h3>
                        <p class="movie-card-year"><?php echo esc_html($movie['year']); ?></p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
}
?>

<h1 class="page-title">Discover Movies</h1>

<?php
global $sam_theme_options;
sam_render_movie_hub_section( $sam_theme_options['movies_hub_recent_title'] ?? 'Recently Added', home_url('/movies/recent/'), ['sort_by' => 'date_added'] );
sam_render_movie_hub_section( $sam_theme_options['movies_hub_trending_title'] ?? 'Trending Movies', home_url('/movies/trending/'), ['sort_by' => 'download_count'] );
sam_render_movie_hub_section( $sam_theme_options['movies_hub_2025_title'] ?? 'Movies of 2025', home_url('/movies/year/2025/'), ['query_term' => '2025', 'sort_by' => 'date_added'] );
sam_render_movie_hub_section( $sam_theme_options['movies_hub_top_rated_title'] ?? 'Top Rated of All Time', home_url('/movies/top-rated/'), ['sort_by' => 'rating', 'minimum_rating' => 8.5] );
?>

<?php get_footer(); ?>