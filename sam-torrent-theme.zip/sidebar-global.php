<?php if ( is_active_sidebar( 'sidebar-global' ) ) : ?>
<aside id="secondary-global" class="widget-area global-sidebar">
	<?php dynamic_sidebar( 'sidebar-global' ); ?>
</aside>
<?php endif; ?>