<?php
/**
 * The sidebar containing the main widget area for TV Shows.
 *
 * @package SamTorrentHub
 */

if ( ! is_active_sidebar( 'sidebar-tv' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area tv-sidebar">
	<?php dynamic_sidebar( 'sidebar-tv' ); // Corrected function name ?>
</aside>