<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="app-container">
    <header class="header">
        
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="header-title"><?php bloginfo( 'name' ); ?></a>
        
        <nav class="header-nav">
            <?php if ( has_nav_menu( 'primary' ) ) {
                wp_nav_menu( ['theme_location' => 'primary', 'container' => false, 'menu_class' => 'header-menu']);
            } ?>
        </nav>

        <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="search" class="search-input" placeholder="Search..." value="<?php echo get_search_query(); ?>" name="s" required>
            <button type="submit" class="search-button">Search</button>
        </form>

        <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </button>

    </header>
    <?php sam_display_ad('ad_header'); ?>
    <main class="main-content">