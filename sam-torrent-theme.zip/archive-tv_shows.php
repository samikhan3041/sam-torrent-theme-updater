<?php
/**
 * The template for displaying TV Show archive pages (Currently Airing, Top Rated, etc.).
 *
 * @package SamTorrentHub
 */

get_header();

$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
$page_title = 'Popular TV Shows';
$base_pagination_url = get_post_type_archive_link('tv_show');
$api_params = ['sort_by' => 'popularity.desc'];

$archive_type = get_query_var('tv_archive_type');
$archive_slug = get_query_var('archive_slug');

if ($archive_type === 'airing') {
    $page_title = ' New TV Shows (2025)';
    $base_pagination_url = home_url('/tv/airing/');
    $api_params = ['first_air_date_year' => 2025, 'sort_by' => 'popularity.desc'];
} elseif ($archive_type === 'top-rated') {
    $page_title = 'Top-Rated Sci-Fi & Fantasy'; // <-- New, more accurate title
    $base_pagination_url = home_url('/tv/top-rated/');
    $api_params = [
        'sort_by'            => 'popularity.desc',
        'with_genres'        => '10765', // Sci-Fi & Fantasy
        'with_original_language' => 'en',
        'vote_average.gte'   => 8,       // User Score >= 8
        'vote_count.gte'     => 500      // Minimum 500 votes
    ];
} elseif ($archive_type === 'network' && $archive_slug) {
    $networks = ['netflix' => 213, 'hbo' => 49];
    $network_name = ucwords(str_replace('-', ' ', $archive_slug));
    $page_title = $network_name . ' TV Shows';
    $base_pagination_url = home_url('/tv/network/' . $archive_slug . '/');
    $api_params = ['with_networks' => $networks[$archive_slug] ?? 0, 'sort_by' => 'popularity.desc'];
} elseif ($archive_type === 'genre' && $archive_slug) {
    $genres = ['sci-fi-action' => '10759']; // Now just Action & Adventure
    $genre_name = 'Action & Adventure';
    $page_title = $genre_name . ' TV Shows';
    $base_pagination_url = home_url('/tv/genre/' . $archive_slug . '/');
    $api_params = ['with_genres' => $genres[$archive_slug] ?? 0, 'sort_by' => 'popularity.desc'];
}

$api_params['page'] = $paged;
$data = get_filtered_tmdb_media('tv', $api_params);
$shows = $data['items'] ?? [];
?>

<h1 class="page-title"><?php echo esc_html($page_title); ?></h1>

<?php if ( ! empty( $shows ) ) : ?>
    <div class="movie-grid">
        <?php foreach ( $shows as $show ) : ?>
            <a href="<?php echo esc_url( home_url( '/tv/' . $show['id'] . '/' . sanitize_title( $show['name'] ) ) ); ?>" class="movie-card">
                <img src="<?php echo get_tmdb_image_url( $show['poster_path'] ); ?>" alt="<?php echo esc_attr( $show['name'] ); ?>">
                <div class="movie-card-info">
                    <h3 class="movie-card-title"><?php echo esc_html( $show['name'] ); ?></h3>
                    <p class="movie-card-year"><?php echo esc_html( substr( $show['first_air_date'], 0, 4 ) ); ?></p>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
    <?php 
    sam_theme_pagination($paged, $data['total_pages'], $base_pagination_url);
    ?>
    <?php sam_display_ad('ad_archive'); ?>
<?php else : ?>
    <p>No TV shows found matching these criteria.</p>
<?php endif; ?>

<?php get_footer(); ?>