<?php


// Load theme options into a global variable
$sam_theme_options = get_option('sam_theme_options_data');
/**
 * Sam Torrent Hub Theme functions and definitions.
 *
 * @package SamTorrentHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// --- CONSTANTS ---



/*
|--------------------------------------------------------------------------
| 1. THEME SETUP
|--------------------------------------------------------------------------
|
| Basic theme setup like navigation menus and post thumbnail support.
|
*/

add_action( 'after_setup_theme', 'sam_theme_setup' );
/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function sam_theme_setup() {
	register_nav_menus( [
		'primary' => __( 'Header Menu', 'samtorrenthub' ),
	] );
	add_theme_support( 'post-thumbnails' );
}


/*
|--------------------------------------------------------------------------
| 2. ENQUEUE STYLES & SCRIPTS
|--------------------------------------------------------------------------
|
| Enqueues the theme's CSS and JavaScript files.
|
*/

add_action( 'wp_enqueue_scripts', 'sam_theme_scripts' );
/**
 * Enqueues scripts and styles for the front end.
 * This is the final, corrected version.
 */
function sam_theme_scripts() {
	wp_enqueue_style( 'sam-main-style', get_stylesheet_uri() );
	wp_enqueue_script( 'sam-main-script', get_template_directory_uri() . '/js/main.js', ['jquery'], '1.0.7', true );

    // --- THIS IS THE FIX ---
    // We now load the navigation script unconditionally. It's a small script,
    // and this ensures it's always available for the hamburger menu to work.
    // The conditional loading was the source of the click bug.
    wp_enqueue_script('sam-navigation-script', get_template_directory_uri() . '/js/navigation.js', ['jquery'], '1.0.2', true);
    // --- END FIX ---

	// This part is essential for other AJAX features and is correctly preserved.
	wp_localize_script(
		'sam-main-script',
		'sam_ajax_object',
		[
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'sam_live_search_nonce' ),
		]
	);
}



add_filter('body_class', 'sam_add_body_classes');
/**
 * Adds custom classes to the body tag based on theme options.
 */
function sam_add_body_classes($classes) {
    global $sam_theme_options;
    $is_hamburger_enabled = $sam_theme_options['enable_hamburger_menu'] ?? '0';

    if ($is_hamburger_enabled === '1') {
        $classes[] = 'mobile-hamburger-enabled';
    }
    return $classes;
}


/*
|--------------------------------------------------------------------------
| 3. HELPER UTILITIES
|--------------------------------------------------------------------------
|
| Small helper functions used throughout the theme.
|
*/

/**
 * Constructs a full TMDB image URL from a given path and size.
 *
 * @param string $path The image path from the API.
 * @param string $size The desired image size (e.g., 'w500', 'original').
 * @return string The full image URL or empty string if no path.
 */
function get_tmdb_image_url( $path, $size = 'w500' ) {
	if ( empty( $path ) ) {
		return '';
	}
	return 'https://image.tmdb.org/t/p/' . $size . $path;
}

/**
 * Formats a size in bytes into a human-readable string (KB, MB, GB).
 *
 * @param int $size_bytes The size in bytes.
 * @return string The formatted size string.
 */
function format_bytes( $size_bytes ) {
    if ( ! $size_bytes ) return "";
    $bytes = (int) $size_bytes;
    if ( $bytes <= 0 ) return "";
    
    $power_labels = [ 0 => 'B', 1 => 'KB', 2 => 'MB', 3 => 'GB', 4 => 'TB' ];
    $power = 1024;
    $n = 0;
    
    while ( $bytes >= $power && $n < count($power_labels) ) {
        $bytes /= $power;
        $n++;
    }
    
    return round( $bytes, 1 ) . ' ' . $power_labels[$n];
}


/*
|--------------------------------------------------------------------------
| 4. PAGINATION
|--------------------------------------------------------------------------
|
| Custom pagination function for archive pages.
|
*/

/**
 * Renders custom pagination links.
 *
 * @param int    $current_page The current page number.
 * @param int    $total_pages  The total number of pages.
 * @param string $base_url     The base URL for pagination links.
 */
function sam_theme_pagination( $current_page, $total_pages, $base_url ) {
	if ( $total_pages <= 1 ) {
		return;
	}

	$links = paginate_links( [
		'base'      => trailingslashit( $base_url ) . 'page/%#%/',
		'format'    => '?paged=%#%',
		'current'   => max( 1, $current_page ),
		'total'     => $total_pages,
		'prev_text' => '« Prev',
		'next_text' => 'Next »',
		'type'      => 'array',
	] );

	if ( is_array( $links ) ) {
		echo '<nav class="pagination">';
		foreach ( $links as $link ) {
			// Add custom 'active' class for the current page link.
			if ( strpos( $link, 'current' ) !== false ) {
				echo str_replace( 'page-numbers current', 'page-numbers active', $link );
			} else {
				echo $link;
			}
		}
		echo '</nav>';
	}
}


/*
|--------------------------------------------------------------------------
| 5. EXTERNAL API FETCHING LOGIC
|--------------------------------------------------------------------------
|
| Functions responsible for communicating with external APIs like YTS and TMDB.
|
*/

/**
 * Searches for movies on the YTS API.
 * @param string $query The search term.
 * @return array The list of movies found.
 */
function search_yts_movies( $query ) {
	$url      = 'https://yts.mx/api/v2/list_movies.json?query_term=' . urlencode( $query ) . '&limit=20';
	$response = wp_remote_get( $url );
	if ( is_wp_error( $response ) ) {
		return [];
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	return $data['data']['movies'] ?? [];
}

/**
 * Searches for TV shows on the TMDB API.
 * @param string $query The search term.
 * @return array The list of TV shows found.
 */
function search_tmdb_shows( $query ) {
	$url      = 'https://api.themoviedb.org/3/search/tv?api_key=' . $GLOBALS['sam_theme_options']['tmdb_api_key'] . '&query=' . urlencode( $query );
	$response = wp_remote_get( $url );
	if ( is_wp_error( $response ) ) {
		return [];
	}
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	return $data['results'] ?? [];
}

/**
 * Gets a filtered list of movies from the YTS API based on params, with caching.
 * @param array $params API parameters (e.g., sort_by, page).
 * @return array An array containing 'items' and 'total_pages'.
 */
function get_filtered_movies_yts( $params = [] ) {
    // Generate a unique key for the cache based on the API parameters.
    $transient_key = 'yts_api_cache_' . md5( http_build_query( $params ) );

    // 1. Check the cache first.
    if ( false !== ( $cached_data = get_transient( $transient_key ) ) ) {
        return $cached_data;
    }

    // 2. If cache not found, proceed with the API call.
    $defaults  = [ 'page' => 1, 'limit' => 20 ];
    $args      = wp_parse_args( $params, $defaults );
    $api_url   = add_query_arg( $args, 'https://yts.mx/api/v2/list_movies.json' );
    $response  = wp_remote_get( $api_url, [ 'timeout' => 20 ] );

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) != 200 ) {
        return [ 'items' => [], 'total_pages' => 0 ]; // Return empty on error
    }

    $data        = json_decode( wp_remote_retrieve_body( $response ), true );
    $movie_count = $data['data']['movie_count'] ?? 0;
    $limit       = $data['data']['limit'] ?? 20;
    $total_pages = ceil( $movie_count / $limit );

    $results = [
        'items'       => $data['data']['movies'] ?? [],
        'total_pages' => $total_pages,
    ];

    // 3. Store the fresh results in the cache for 3 hours.
    set_transient( $transient_key, $results, 3 * HOUR_IN_SECONDS );

    return $results;
}

/**
 * Gets a filtered list of media (movies or TV) from the TMDB API, with caching.
 * @param string $type   'tv' or 'movie'.
 * @param array  $params API parameters (e.g., with_genres, page).
 * @return array An array containing 'items' and 'total_pages'.
 */
function get_filtered_tmdb_media( $type = 'tv', $params = [] ) {
    // Generate a unique key for the cache based on the type and API parameters.
    $transient_key = 'tmdb_api_cache_' . $type . '_' . md5( http_build_query( $params ) );

    // 1. Check the cache first.
    if ( false !== ( $cached_data = get_transient( $transient_key ) ) ) {
        return $cached_data;
    }

    // 2. If cache not found, proceed with the API call.
    $defaults  = [ 'page' => 1, 'max_pages' => 500 ];
    $args      = wp_parse_args( $params, $defaults );
    $max_pages = $args['max_pages'];
    unset( $args['max_pages'] );

    $endpoint  = ( $type === 'movie' ) ? 'discover/movie' : 'discover/tv';
    $api_url   = add_query_arg( $args, 'https://api.themoviedb.org/3/' . $endpoint );
    $api_url   = add_query_arg( 'api_key', $GLOBALS['sam_theme_options']['tmdb_api_key'], $api_url );
    $response  = wp_remote_get( $api_url, [ 'timeout' => 20 ] );

    if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) != 200 ) {
        return [ 'items' => [], 'total_pages' => 0 ]; // Return empty on error
    }

    $data        = json_decode( wp_remote_retrieve_body( $response ), true );
    $total_pages = $data['total_pages'] ?? 1;
    $final_total_pages = min( $total_pages, $max_pages ); // Respect the 500-page limit

    $results = [
        'items'       => $data['results'] ?? [],
        'total_pages' => $final_total_pages,
    ];

    // 3. Store the fresh results in the cache for 3 hours.
    set_transient( $transient_key, $results, 3 * HOUR_IN_SECONDS );

    return $results;
}


/*
|--------------------------------------------------------------------------
| 6. URL HANDLING & TEMPLATE ROUTING
|--------------------------------------------------------------------------
|
| Defines custom rewrite rules and query vars to handle friendly URLs
| and route them to the correct templates or handlers.
|
*/

add_action( 'init', 'sam_register_rewrite_rules' );
/**
 * Registers all custom rewrite rules for the theme.
 */
function sam_register_rewrite_rules() {

        // Rule for Intermediate Download Page
    add_rewrite_rule( '^download/([0-9]+)/([0-9]+)/?$', 'index.php?download_post_id=$matches[1]&download_link_index=$matches[2]', 'top' );
    // Detail Page Rules
    add_rewrite_rule( '^movie/([0-9]+)/([^/]+)?/?$', 'index.php?is_detail_page=1&media_type=movie&media_id=$matches[1]', 'top' );
    add_rewrite_rule( '^tv/([0-9]+)/([^/]+)?/?$', 'index.php?is_detail_page=1&media_type=tv&media_id=$matches[1]', 'top' );

    // TV Show Archive Rules
    add_rewrite_rule( '^tv/airing/page/([0-9]+)?/?$', 'index.php?post_type=tv_show&tv_archive_type=airing&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^tv/airing/?$', 'index.php?post_type=tv_show&tv_archive_type=airing', 'top' );
    add_rewrite_rule( '^tv/top-rated/page/([0-9]+)?/?$', 'index.php?post_type=tv_show&tv_archive_type=top-rated&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^tv/top-rated/?$', 'index.php?post_type=tv_show&tv_archive_type=top-rated', 'top' );
    add_rewrite_rule( '^tv/network/([^/]+)/page/([0-9]+)?/?$', 'index.php?post_type=tv_show&tv_archive_type=network&archive_slug=$matches[1]&paged=$matches[2]', 'top' );
    add_rewrite_rule( '^tv/network/([^/]+)/?$', 'index.php?post_type=tv_show&tv_archive_type=network&archive_slug=$matches[1]', 'top' );
    add_rewrite_rule( '^tv/genre/([^/]+)/page/([0-9]+)?/?$', 'index.php?post_type=tv_show&tv_archive_type=genre&archive_slug=$matches[1]&paged=$matches[2]', 'top' );
    add_rewrite_rule( '^tv/genre/([^/]+)/?$', 'index.php?post_type=tv_show&tv_archive_type=genre&archive_slug=$matches[1]', 'top' );

    // Movie Archive Rules
    add_rewrite_rule( '^movies/recent/page/([0-9]+)?/?$', 'index.php?post_type=movie&movie_archive_type=recent&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^movies/recent/?$', 'index.php?post_type=movie&movie_archive_type=recent', 'top' );
    add_rewrite_rule( '^movies/trending/page/([0-9]+)?/?$', 'index.php?post_type=movie&movie_archive_type=trending&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^movies/trending/?$', 'index.php?post_type=movie&movie_archive_type=trending', 'top' );
    add_rewrite_rule( '^movies/top-rated/page/([0-9]+)?/?$', 'index.php?post_type=movie&movie_archive_type=top-rated&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^movies/top-rated/?$', 'index.php?post_type=movie&movie_archive_type=top-rated', 'top' );
    add_rewrite_rule( '^movies/year/([0-9]+)/page/([0-9]+)?/?$', 'index.php?post_type=movie&movie_archive_type=year&archive_slug=$matches[1]&paged=$matches[2]', 'top' );
    add_rewrite_rule( '^movies/year/([0-9]+)/?$', 'index.php?post_type=movie&movie_archive_type=year&archive_slug=$matches[1]', 'top' );
    add_rewrite_rule( '^movies/genre/([^/]+)/page/([0-9]+)?/?$', 'index.php?post_type=movie&movie_archive_type=genre&archive_slug=$matches[1]&paged=$matches[2]', 'top' );
    add_rewrite_rule( '^movies/genre/([^/]+)/?$', 'index.php?post_type=movie&movie_archive_type=genre&archive_slug=$matches[1]', 'top' );
}

add_filter( 'query_vars', 'sam_register_query_vars' );
/**
 * Adds custom query variables to WordPress.
 * @param array $vars The array of existing query variables.
 * @return array The modified array of query variables.
 */
function sam_register_query_vars( $vars ) {
	$vars[] = 'is_detail_page';
	$vars[] = 'media_type';
	$vars[] = 'media_id';
	$vars[] = 'tv_archive_type';
	$vars[] = 'movie_archive_type';
	$vars[] = 'archive_slug';
    $vars[] = 'download_post_id';
    $vars[] = 'download_link_index';
	return $vars;
}

add_filter( 'template_include', 'sam_template_include' );
/**
 * Loads the correct template file for our custom archive pages.
 * @param string $template The template file WordPress plans to use.
 * @return string The path to the correct template file.
 */
function sam_template_include( $template ) {
    if ( get_query_var( 'download_post_id' ) ) {
        $new_template = get_template_directory() . '/page-download.php';
        if ( file_exists($new_template) ) { return $new_template; }
    }
	if ( get_query_var( 'tv_archive_type' ) ) {
		$new_template = get_template_directory() . '/archive-tv_shows.php';
		if ( file_exists( $new_template ) ) {
			return $new_template;
		}
	}
	if ( get_query_var( 'movie_archive_type' ) ) {
		$new_template = get_template_directory() . '/archive-movie.php';
		if ( file_exists( $new_template ) ) {
			return $new_template;
		}
	}
	return $template;
}


/*
|--------------------------------------------------------------------------
| 7. CUSTOM POST TYPES & TAXONOMIES
|--------------------------------------------------------------------------
|
| Registers the 'Movie' and 'TV Show' custom post types and 'Genre' taxonomy.
|
*/

add_action( 'init', 'sam_register_post_types', 0 );
/**
 * Registers custom post types and taxonomies.
 */
function sam_register_post_types() {
	// Register Movie CPT
	$movie_labels = [
		'name'          => 'Movies',
		'singular_name' => 'Movie',
		'menu_name'     => 'Movies',
		'all_items'     => 'All Movies',
		'add_new'       => 'Add New',
		'add_new_item'  => 'Add New Movie',
		'edit_item'     => 'Edit Movie',
	];
	$movie_args   = [
		'label'        => 'Movie',
		'labels'       => $movie_labels,
		'public'       => true,
		'has_archive'  => true,
		'rewrite'      => [ 'slug' => 'movies' ],
		'menu_icon'    => 'dashicons-video-alt3',
		'supports'     => [ 'title', 'editor', 'thumbnail', 'comments' ],
		'show_in_rest' => true,
	];
	register_post_type( 'movie', $movie_args );

	// Register TV Show CPT
	$tv_show_labels = [
		'name'          => 'TV Shows',
		'singular_name' => 'TV Show',
		'menu_name'     => 'TV Shows',
		'all_items'     => 'All TV Shows',
		'add_new'       => 'Add New',
		'add_new_item'  => 'Add New TV Show',
		'edit_item'     => 'Edit TV Show',
	];
	$tv_show_args   = [
		'label'        => 'TV Show',
		'labels'       => $tv_show_labels,
		'public'       => true,
		'has_archive'  => true,
		'rewrite'      => [ 'slug' => 'tv-shows' ],
		'menu_icon'    => 'dashicons-desktop',
		'supports'     => [ 'title', 'editor', 'thumbnail', 'comments' ],
		'show_in_rest' => true,
	];
	register_post_type( 'tv_show', $tv_show_args );

	// Register Genre Taxonomy for both CPTs
	$genre_labels = [
		'name'          => 'Genres',
		'singular_name' => 'Genre',
		'menu_name'     => 'Genres',
	];
	register_taxonomy( 'genre', [ 'movie', 'tv_show' ], [
		'hierarchical' => true,
		'labels'       => $genre_labels,
		'show_ui'      => true,
		'show_in_rest' => true,
		'rewrite'      => [ 'slug' => 'genre' ],
	] );

        // Register Actor Taxonomy for both CPTs
    $actor_labels = [
        'name'          => 'Actors',
        'singular_name' => 'Actor',
        'menu_name'     => 'Actors',
        'search_items'  => 'Search Actors',
        'all_items'     => 'All Actors',
        'edit_item'     => 'Edit Actor',
        'update_item'   => 'Update Actor',
        'add_new_item'  => 'Add New Actor',
        'new_item_name' => 'New Actor Name',
    ];
    register_taxonomy( 'actor', [ 'movie', 'tv_show' ], [
        'hierarchical'      => false, // Makes it tag-like
        'labels'            => $actor_labels,
        'show_ui'           => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => [ 'slug' => 'actor' ],
    ] );


}




/*
|--------------------------------------------------------------------------
| 8. SIDEBARS & WIDGETS
|--------------------------------------------------------------------------
|
| Registers sidebar areas and custom widgets.
|
*/

// Include custom widget classes.
require get_template_directory() . '/widgets/widget-featured-movies.php';
require get_template_directory() . '/widgets/widget-featured-tvshows.php';

add_action( 'widgets_init', 'sam_widgets_init' );
/**
 * Initializes widget areas and registers custom widgets.
 */
function sam_widgets_init() {


	// Register Sidebar Areas
	register_sidebar( [
		'name'          => esc_html__( 'Global Sidebar', 'samtorrenthub' ),
		'id'            => 'sidebar-global',
		'description'   => esc_html__( 'Appears at the top of the sidebar on all detail pages.', 'samtorrenthub' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	] );

	register_sidebar( [
		'name'          => esc_html__( 'Movie Sidebar', 'samtorrenthub' ),
		'id'            => 'sidebar-movie',
		'description'   => esc_html__( 'Appears on single Movie and TV Show pages.', 'samtorrenthub' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	] );

	register_sidebar( [
		'name'          => esc_html__( 'TV Show Sidebar', 'samtorrenthub' ),
		'id'            => 'sidebar-tv',
		'description'   => esc_html__( 'Appears on single TV Show and Movie pages.', 'samtorrenthub' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	] );

	register_sidebar( [
		'name'          => esc_html__( 'Featured Movies Widget Area', 'samtorrenthub' ),
		'id'            => 'sidebar-movie-featured',
		'description'   => esc_html__( 'Widget area for featured movies.', 'samtorrenthub' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	] );

	register_sidebar( [
		'name'          => esc_html__( 'Featured TV Shows Widget Area', 'samtorrenthub' ),
		'id'            => 'sidebar-tv-featured',
		'description'   => esc_html__( 'Widget area for featured TV shows.', 'samtorrenthub' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	] );

	// Register Custom Widgets
	register_widget( 'Sam_Featured_Movies_Widget' );
	register_widget( 'Sam_Featured_TV_Widget' );
}


/*
|--------------------------------------------------------------------------
| 9. ADMIN AJAX FETCHER
|--------------------------------------------------------------------------
|
| Adds the TMDB Fetcher meta box to the post editor and handles the
| associated AJAX requests for searching and populating data.
|
*/

add_action( 'add_meta_boxes', 'sam_add_tmdb_meta_box' );
/**
 * Adds the TMDB Fetcher meta box to movie and TV show edit screens.
 */
function sam_add_tmdb_meta_box() {
	add_meta_box(
		'sam_tmdb_fetcher',
		'TMDB Fetcher',
		'sam_render_tmdb_meta_box',
		[ 'movie', 'tv_show' ],
		'side',
		'high'
	);
}

/**
 * Renders the HTML content for the TMDB Fetcher meta box.
 * @param WP_Post $post The current post object.
 */
function sam_render_tmdb_meta_box( $post ) {
	$media_type = ( get_post_type( $post ) === 'tv_show' ) ? 'tv' : 'movie';
	?>
	<p><?php esc_html_e( 'Search for a title to automatically populate fields.', 'samtorrenthub' ); ?></p>
	<input type="hidden" id="sam-tmdb-type" value="<?php echo esc_attr( $media_type ); ?>">

	<label for="sam-tmdb-query"><b><?php esc_html_e( 'Search Title:', 'samtorrenthub' ); ?></b></label>
	<input type="text" id="sam-tmdb-query" style="width: 100%; margin-top: 5px;">

	<button type="button" id="sam-tmdb-fetch-button" class="button button-primary" style="width: 100%; margin-top: 10px;">
		<?php esc_html_e( 'Fetch Details', 'samtorrenthub' ); ?>
	</button>
	<div id="sam-tmdb-results" style="margin-top: 15px;"></div>
	<?php
}

add_action( 'admin_enqueue_scripts', 'sam_enqueue_admin_scripts' );
/**
 * Enqueues the admin-specific JavaScript for the fetcher.
 * @param string $hook The current admin page hook.
 */
function sam_enqueue_admin_scripts( $hook ) {
	global $post;
	if ( ( 'post-new.php' === $hook || 'post.php' === $hook ) && in_array( $post->post_type, [ 'movie', 'tv_show' ] ) ) {
		wp_enqueue_script( 'sam-admin-script', get_template_directory_uri() . '/js/admin-scripts.js', [ 'jquery' ], '1.0.1', true );
		wp_localize_script( 'sam-admin-script', 'sam_admin_vars', [
			'nonce'   => wp_create_nonce( 'sam_admin_nonce' ),
			'post_id' => $post->ID,
		] );
	}
}

add_action( 'wp_ajax_sam_search_tmdb', 'sam_search_tmdb' );
/**
 * AJAX handler for searching TMDB.
 */
function sam_search_tmdb() {
	check_ajax_referer( 'sam_admin_nonce', 'nonce' );

	$query = sanitize_text_field( $_POST['query'] );
	$type  = in_array( $_POST['type'], [ 'movie', 'tv' ] ) ? $_POST['type'] : 'movie';
	$url   = "https://api.themoviedb.org/3/search/{$type}?api_key=" . $GLOBALS['sam_theme_options']['tmdb_api_key'] . '&query=' . urlencode( $query );

	$response = wp_remote_get( $url );
	if ( is_wp_error( $response ) ) {
		wp_send_json_error( 'API request failed.' );
	}

	$data    = json_decode( wp_remote_retrieve_body( $response ), true );
	$results = [];

	if ( ! empty( $data['results'] ) ) {
		foreach ( array_slice( $data['results'], 0, 5 ) as $item ) {
			$results[] = [
				'id'    => $item['id'],
				'title' => ( 'movie' === $type ? $item['title'] : $item['name'] ),
				'year'  => ( 'movie' === $type ? substr( $item['release_date'], 0, 4 ) : substr( $item['first_air_date'], 0, 4 ) ),
			];
		}
	}
	wp_send_json_success( $results );
}

add_action( 'wp_ajax_sam_get_tmdb_details', 'sam_get_tmdb_details' );
/**
 * AJAX handler for fetching full details from TMDB and populating post fields.
 */
function sam_get_tmdb_details() {
	check_ajax_referer( 'sam_admin_nonce', 'nonce' );

	$tmdb_id  = absint( $_POST['tmdb_id'] );
	$post_id  = absint( $_POST['post_id'] );
	$type     = in_array( $_POST['type'], [ 'movie', 'tv' ] ) ? $_POST['type'] : 'movie';
	$url      = "https://api.themoviedb.org/3/{$type}/{$tmdb_id}?api_key=" . $GLOBALS['sam_theme_options']['tmdb_api_key'];
	$response = wp_remote_get( $url );

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( 'API request for details failed.' );
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $data ) ) {
		wp_send_json_error( 'Could not retrieve details from TMDB.' );
	}

	// Prepare data for JSON response
	$output = [
		'title'         => ( 'movie' === $type ? $data['title'] : $data['name'] ),
		'overview'      => $data['overview'],
		'year'          => ( 'movie' === $type ? substr( $data['release_date'], 0, 4 ) : substr( $data['first_air_date'], 0, 4 ) ),
		'rating'        => round( $data['vote_average'], 1 ),
		'tmdb_id'       => $data['id'],
		'backdrop_path' => $data['backdrop_path'],
		'genres'        => wp_list_pluck( $data['genres'], 'name' ),
	];

	// Sideload the poster image and set it as the post thumbnail
	if ( ! empty( $data['poster_path'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$image_url     = 'https://image.tmdb.org/t/p/w500' . $data['poster_path'];
		$attachment_id = media_handle_sideload( [
			'tmp_name' => download_url( $image_url ),
			'name'     => $data['id'] . '.jpg',
		], $post_id, $output['title'] );

		if ( ! is_wp_error( $attachment_id ) ) {
			set_post_thumbnail( $post_id, $attachment_id );
			$output['attachment_id'] = $attachment_id;
		}
	}

	wp_send_json_success( $output );
}


/*
|--------------------------------------------------------------------------
| 10. LIVE DATA FETCHER
|--------------------------------------------------------------------------
|
| Fetches live, on-demand data from TMDB for single post pages,
| using transients for caching.
|
*/

/**
 * Gets live details for a movie/show from TMDB, with caching.
 * @param int    $tmdb_id The TMDB ID.
 * @param string $type    'movie' or 'tv'.
 * @return array|null The API data or null on failure.
 */
function get_live_tmdb_details( $tmdb_id, $type = 'movie' ) {
	if ( empty( $tmdb_id ) ) {
		return null;
	}

	$cache_key = "live_{$type}_details_{$tmdb_id}";
	if ( false !== ( $cached_data = get_transient( $cache_key ) ) ) {
		return $cached_data;
	}

	$url      = "https://api.themoviedb.org/3/{$type}/{$tmdb_id}?api_key=" . $GLOBALS['sam_theme_options']['tmdb_api_key'] . '&append_to_response=credits,recommendations,external_ids';
	$response = wp_remote_get( $url, [ 'timeout' => 15 ] );

	if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) != 200 ) {
		return null;
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS ); // Cache for 6 hours
	return $data;
}


/*
|--------------------------------------------------------------------------
| 11. HYBRID CONTENT ENGINE
|--------------------------------------------------------------------------
|
| The core engine that checks if content exists locally and, if not,
| creates it on-the-fly from API data.
|
*/

/**
 * Checks for a local post by API ID; if not found, creates it using native meta fields.
 * @param string|int $id   The API ID (YTS or TMDB).
 * @param string     $type 'movie' or 'tv'.
 * @return int|null The post ID or null on failure.
 */
function sam_get_or_create_post_from_tmdb_id( $id, $type = 'movie' ) {
    global $sam_theme_options;
	if ( empty( $id ) ) return null;

	$post_type = ( 'tv' === $type ) ? 'tv_show' : 'movie';
	$meta_key  = ( 'movie' === $type && is_numeric( $id ) && strlen( (string) $id ) < 6 ) ? '_sam_yts_id' : '_sam_tmdb_id';
	
    $existing_posts = get_posts( [ 'post_type' => $post_type, 'post_status' => [ 'publish', 'draft' ], 'meta_query' => [ [ 'key' => $meta_key, 'value' => $id ] ], 'posts_per_page' => 1, 'fields' => 'ids' ] );
	if ( ! empty( $existing_posts ) ) { return $existing_posts[0]; }
    
    $api_key = $sam_theme_options['tmdb_api_key'] ?? '';
	if (empty($api_key)) { return null; } // Can't proceed without an API key

	$yts_data = null; 
    $tmdb_data = null; 
    $final_tmdb_id = null;

    // Step 1: Determine the definitive TMDB ID.
    if ($meta_key === '_sam_yts_id') {
        // We started with a YTS ID, so find its corresponding TMDB ID via IMDB.
        $yts_url = 'https://yts.mx/api/v2/movie_details.json?movie_id=' . $id; 
        $response = wp_remote_get($yts_url);
        if (!is_wp_error($response)) { 
            $yts_data = json_decode(wp_remote_retrieve_body($response), true)['data']['movie'] ?? null; 
        }
        if ($yts_data && !empty($yts_data['imdb_code'])) {
            $tmdb_find_url = "https://api.themoviedb.org/3/find/{$yts_data['imdb_code']}?api_key={$api_key}&external_source=imdb_id";
            $response = wp_remote_get($tmdb_find_url);
            if (!is_wp_error($response)) { 
                $tmdb_find_data = json_decode(wp_remote_retrieve_body($response), true);
                $final_tmdb_id = $tmdb_find_data['movie_results'][0]['id'] ?? null;
            }
        }
    } else { 
        // We started with a TMDB ID.
        $final_tmdb_id = $id; 
    }

    if (empty($final_tmdb_id)) { return null; } // Stop if we couldn't find a TMDB ID.

    // Step 2: Make one definitive API call to get all data, including cast.
    $tmdb_url = "https://api.themoviedb.org/3/{$type}/{$final_tmdb_id}?api_key={$api_key}&append_to_response=credits,external_ids";
    $response = wp_remote_get($tmdb_url);
    if (is_wp_error($response)) { return null; }
    $tmdb_data = json_decode(wp_remote_retrieve_body($response), true);
    if (empty($tmdb_data)) { return null; }

	// Step 3: Create the post.
	$post_title = $yts_data['title_long'] ?? $tmdb_data['title'] ?? $tmdb_data['name'];
	$post_id = wp_insert_post(['post_title' => $post_title, 'post_content' => '', 'post_status' => 'publish', 'post_type' => $post_type]);
	if (is_wp_error($post_id)) { return null; }

	// Step 4: Update all meta fields using the best available data.
	update_post_meta($post_id, '_sam_yts_id', $yts_data['id'] ?? '');
	update_post_meta($post_id, '_sam_tmdb_id', $tmdb_data['id'] ?? '');
	update_post_meta($post_id, '_sam_year', $yts_data['year'] ?? substr($tmdb_data['release_date'] ?? $tmdb_data['first_air_date'], 0, 4));
	update_post_meta($post_id, '_sam_rating', $yts_data['rating'] ?? round($tmdb_data['vote_average'], 1));
	update_post_meta($post_id, '_sam_synopsis', $yts_data['description_full'] ?? $tmdb_data['overview']);
	update_post_meta($post_id, '_sam_backdrop_path', $tmdb_data['backdrop_path'] ?? '');
	$genres = !empty($yts_data['genres']) ? $yts_data['genres'] : wp_list_pluck($tmdb_data['genres'] ?? [], 'name');
	update_post_meta($post_id, '_sam_genres_text', implode(', ', $genres));
    
    // Step 5: Assign Actor Terms using the definitive TMDB data.
    $cast_members = $tmdb_data['credits']['cast'] ?? null;
    if (!empty($cast_members)) {
        $actor_names = wp_list_pluck(array_slice($cast_members, 0, 15), 'name');
        wp_set_post_terms($post_id, $actor_names, 'actor', false);
    }

    // Step 6: Handle torrent data.
	if ($type === 'movie' && !empty($yts_data['torrents'])) {
		$titles = []; $magnets = [];
		foreach ($yts_data['torrents'] as $torrent) {
			$titles[] = $torrent['quality'] . ' (' . $torrent['size'] . ')'; 
            $magnets[] = 'magnet:?xt=urn:btih:'.$torrent['hash'].'&dn='.urlencode($post_title);
		}
		update_post_meta($post_id, '_sam_torrent_titles', implode("\n", $titles)); 
        update_post_meta($post_id, '_sam_magnet_links', implode("\n", $magnets));
	} elseif ($type === 'tv' && !empty($tmdb_data['external_ids']['imdb_id'])) {
        $imdb_id = $tmdb_data['external_ids']['imdb_id']; 
        $eztv_torrents = [];
        for ($page = 1; $page <= 5; $page++) {
            $eztv_url = 'https://eztvx.to/api/get-torrents?imdb_id=' . str_replace('tt', '', $imdb_id) . '&limit=100&page=' . $page;
            $eztv_response = wp_remote_get($eztv_url); 
            if (is_wp_error($eztv_response)) break;
            $eztv_data = json_decode(wp_remote_retrieve_body($eztv_response), true); 
            if (empty($eztv_data['torrents'])) break;
            $eztv_torrents = array_merge($eztv_torrents, $eztv_data['torrents']);
        }
        if (!empty($eztv_torrents)) {
            $formatted_lines = []; $grouped_by_episode = [];
            foreach ($eztv_torrents as $torrent) {
                $key = "S" . str_pad($torrent['season'], 2, '0', STR_PAD_LEFT) . "E" . str_pad($torrent['episode'], 2, '0', STR_PAD_LEFT);
                $grouped_by_episode[$key][] = $torrent;
            }
            ksort($grouped_by_episode);
            foreach ($grouped_by_episode as $ep_key => $torrents) {
                foreach ($torrents as $torrent) {
                    $quality = 'HDTV'; 
                    if (stripos($torrent['filename'], '1080p') !== false) $quality = '1080p'; 
                    elseif (stripos($torrent['filename'], '720p') !== false) $quality = '720p';
                    $size = format_bytes($torrent['size_bytes']); 
                    $formatted_lines[] = "{$ep_key} | {$quality} | {$size} | {$torrent['magnet_url']}";
                } $formatted_lines[] = "";
            }
            update_post_meta($post_id, '_sam_torrents_data', implode("\n", $formatted_lines));
        }
    }
    
	// Step 7: Sideload poster image.
	$poster_url = $yts_data['large_cover_image'] ?? get_tmdb_image_url($tmdb_data['poster_path'] ?? '');
	if (!empty($poster_url)) {
		require_once(ABSPATH . 'wp-admin/includes/media.php'); 
        require_once(ABSPATH . 'wp-admin/includes/file.php'); 
        require_once(ABSPATH . 'wp-admin/includes/image.php');
		$attachment_id = media_handle_sideload(['tmp_name' => download_url($poster_url), 'name' => ($tmdb_data['id'] ?? $yts_data['id']) . '.jpg'], $post_id, $post_title);
		if (!is_wp_error($attachment_id)) { 
            set_post_thumbnail($post_id, $attachment_id); 
        }
	}
	return $post_id;
}


/*
|--------------------------------------------------------------------------
| 12. HYBRID ENGINE REDIRECT HANDLER
|--------------------------------------------------------------------------
|
| Hooks into `template_redirect` to intercept API-driven URLs,
| create content if needed, and redirect to the canonical local URL.
|
*/

add_action( 'template_redirect', 'sam_hybrid_engine_redirect_handler' );
/**
 * Main handler for the hybrid engine's redirection flow.
 */
function sam_hybrid_engine_redirect_handler() {
	if ( get_query_var( 'is_detail_page' ) && get_query_var( 'media_id' ) ) {
		$post_id = sam_get_or_create_post_from_tmdb_id( get_query_var( 'media_id' ), get_query_var( 'media_type' ) );
		if ( $post_id ) {
			wp_safe_redirect( get_permalink( $post_id ) );
			exit;
		}
	}
}


/*
|--------------------------------------------------------------------------
| 13. TV SHOW TORRENT PARSER & UPDATER
|--------------------------------------------------------------------------
|
| Functions for parsing the custom torrent data format and automatically
| updating TV shows with new episodes.
|
*/

/**
 * Parses the raw torrent data from the ACF field into a structured array.
 * @param string $raw_data The raw text data from the 'torrents_data' field.
 * @return array A structured array of seasons, episodes, and torrents.
 */
function sam_parse_tv_torrents_data( $raw_data ) {
	if ( empty( $raw_data ) ) return [];

	$lines   = explode( "\n", trim( $raw_data ) );
	$seasons = [];

	foreach ( $lines as $line ) {
		$parts = explode( '|', $line, 4 );
		if ( count( $parts ) < 4 ) continue;

		$ep_info = trim( $parts[0] );
		$quality = trim( $parts[1] );
		$size    = trim( $parts[2] );
		$magnet  = trim( $parts[3] );

		if ( preg_match( '/S(\d+)E(\d+)/i', $ep_info, $matches ) ) {
			// Regular episode
			$season_num  = (int) $matches[1];
			$episode_num = (int) $matches[2];
			$seasons[ $season_num ]['episodes'][ $episode_num ][] = [
				'quality' => $quality,
				'size'    => $size,
				'magnet'  => $magnet,
			];
		} elseif ( preg_match( '/S(\d+)PACK/i', $ep_info, $matches ) ) {
			// Season pack
			$season_num = (int) $matches[1];
			$seasons[ $season_num ]['packs'][] = [
				'title'  => $quality,
				'size'   => $size,
				'magnet' => $magnet,
			];
		}
	}
	return $seasons;
}

/**
 * Checks for and adds new torrents to a TV show post if they aren't already present.
 * @param int $post_id The ID of the TV show post to update.
 */
/**
 * Checks for and adds new torrents to a TV show post if they aren't already present.
 * @param int $post_id The ID of the TV show post to update.
 */
function sam_update_tv_show_torrents_if_needed($post_id) {
	$transient_key = 'checked_torrents_' . $post_id;
	if (get_transient($transient_key)) return;

	$tmdb_id = get_post_meta($post_id, '_sam_tmdb_id', true); // REPLACED
	$live_data = get_live_tmdb_details($tmdb_id, 'tv');
	$imdb_id = $live_data['external_ids']['imdb_id'] ?? null;
	if (!$imdb_id) return;

	$api_torrents = [];
	for ($page = 1; $page <= 5; $page++) {
		$eztv_url = 'https://eztvx.to/api/get-torrents?imdb_id=' . str_replace('tt', '', $imdb_id) . '&limit=100&page=' . $page;
		$eztv_response = wp_remote_get($eztv_url); if (is_wp_error($eztv_response)) break;
		$eztv_data = json_decode(wp_remote_retrieve_body($eztv_response), true); if (empty($eztv_data['torrents'])) break;
		$api_torrents = array_merge($api_torrents, $eztv_data['torrents']);
	}
	if (empty($api_torrents)) {
		set_transient($transient_key, 'checked', 12 * HOUR_IN_SECONDS); return;
	}

	$existing_data = get_post_meta($post_id, '_sam_torrents_data', true); // REPLACED
	$existing_magnets = [];
	$lines = explode("\n", trim($existing_data));
	foreach ($lines as $line) {
		$parts = explode('|', $line, 4); if (count($parts) === 4) { $existing_magnets[] = trim($parts[3]); }
	}

	$new_lines_to_add = [];
	foreach ($api_torrents as $torrent) {
		if (!in_array($torrent['magnet_url'], $existing_magnets)) {
			$quality = 'HDTV'; if (stripos($torrent['filename'], '1080p') !== false) $quality = '1080p'; elseif (stripos($torrent['filename'], '720p') !== false) $quality = '720p';
			$size = format_bytes($torrent['size_bytes']);
			$ep_key = "S" . str_pad($torrent['season'], 2, '0', STR_PAD_LEFT) . "E" . str_pad($torrent['episode'], 2, '0', STR_PAD_LEFT);
			$new_lines_to_add[$ep_key][] = "{$ep_key} | {$quality} | {$size} | {$torrent['magnet_url']}";
		}
	}

	if (!empty($new_lines_to_add)) {
		$final_new_lines = []; ksort($new_lines_to_add);
		foreach($new_lines_to_add as $episode_group) {
			$final_new_lines = array_merge($final_new_lines, $episode_group); $final_new_lines[] = "";
		}
		$updated_data = trim($existing_data) . "\n\n" . implode("\n", $final_new_lines);
		update_post_meta($post_id, '_sam_torrents_data', $updated_data); // REPLACED
	}
	set_transient($transient_key, 'checked', 12 * HOUR_IN_SECONDS);
}


/*
|--------------------------------------------------------------------------
| 14. WP-CRON AUTO UPDATER
|--------------------------------------------------------------------------
|
| Schedules a recurring event to automatically check for new torrents
| for existing TV shows.
|
*/

// Schedule the cron event if it's not already scheduled.
if ( ! wp_next_scheduled( 'sam_torrent_update_cron' ) ) {
	wp_schedule_event( time(), 'twicedaily', 'sam_torrent_update_cron' );
}

add_action( 'sam_torrent_update_cron', 'sam_run_daily_torrent_update' );
/**
 * The function that runs on the cron schedule.
 */
function sam_run_daily_torrent_update() {
	$args = [
		'post_type'      => 'tv_show',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	];
	$tv_show_ids = get_posts( $args );

	if ( ! empty( $tv_show_ids ) ) {
		foreach ( $tv_show_ids as $post_id ) {
			// Only update if the post hasn't been modified recently to save resources.
			$modified_time = get_the_modified_time( 'U', $post_id );
			if ( ( time() - $modified_time ) > ( 12 * HOUR_IN_SECONDS ) ) {
				sam_update_tv_show_torrents_if_needed( $post_id );
			}
		}
	}
}


/*
|--------------------------------------------------------------------------
| 15. THEME CUSTOMIZER SETTINGS
|--------------------------------------------------------------------------
|
| Adds options to the WordPress Theme Customizer for changing hub page titles.
|
*/








/*
|--------------------------------------------------------------------------
| 16. NATIVE META BOXES (ACF REPLACEMENT)
|--------------------------------------------------------------------------
|
| Replaces the ACF plugin dependency by creating native WordPress
| meta boxes and handling the data saving.
|
*/

add_action( 'add_meta_boxes', 'sam_add_media_details_meta_box' );
/**
 * Registers the main meta box for our custom fields.
 */
function sam_add_media_details_meta_box() {
    $screens = [ 'movie', 'tv_show' ];
    foreach ( $screens as $screen ) {
        add_meta_box(
            'sam_media_details_box',          // Unique ID
            'Media Details',                  // Box title
            'sam_render_media_details_meta_box', // Content callback function
            $screen                           // Post type
        );
    }
}

/**
 * Renders the HTML for the 'Media Details' meta box.
 *
 * @param WP_Post $post The post object.
 */
function sam_render_media_details_meta_box( $post ) {
    // Add a nonce field for security.
    wp_nonce_field( 'sam_save_media_details', 'sam_media_details_nonce' );

    // Get existing meta values.
    $year           = get_post_meta( $post->ID, '_sam_year', true );
    $rating         = get_post_meta( $post->ID, '_sam_rating', true );
    $backdrop_path  = get_post_meta( $post->ID, '_sam_backdrop_path', true );
    $tmdb_id        = get_post_meta( $post->ID, '_sam_tmdb_id', true );
    $synopsis       = get_post_meta( $post->ID, '_sam_synopsis', true );
    $genres_text    = get_post_meta( $post->ID, '_sam_genres_text', true );
    $torrent_titles = get_post_meta( $post->ID, '_sam_torrent_titles', true );
    $magnet_links   = get_post_meta( $post->ID, '_sam_magnet_links', true );
    $torrents_data  = get_post_meta( $post->ID, '_sam_torrents_data', true );

    // Simple styling for the meta box.
    echo '<style>.sam-meta-field{margin-bottom:15px;} .sam-meta-field label{display:block;font-weight:bold;margin-bottom:5px;} .sam-meta-field input, .sam-meta-field textarea{width:100%;} .sam-meta-field small{color:#666;}</style>';

    ?>
    <div class="sam-meta-field">
        <label for="sam_year">Year</label>
        <input type="text" id="sam_year" name="sam_year" value="<?php echo esc_attr( $year ); ?>">
    </div>
    <div class="sam-meta-field">
        <label for="sam_rating">Rating</label>
        <input type="text" id="sam_rating" name="sam_rating" value="<?php echo esc_attr( $rating ); ?>">
    </div>
    <div class="sam-meta-field">
        <label for="sam_backdrop_path">Backdrop Path</label>
        <input type="text" id="sam_backdrop_path" name="sam_backdrop_path" value="<?php echo esc_attr( $backdrop_path ); ?>">
    </div>
    <div class="sam-meta-field">
        <label for="sam_tmdb_id">TMDB ID</label>
        <input type="text" id="sam_tmdb_id" name="sam_tmdb_id" value="<?php echo esc_attr( $tmdb_id ); ?>">
    </div>
    <div class="sam-meta-field">
        <label for="sam_genres_text">Genres Text</label>
        <input type="text" id="sam_genres_text" name="sam_genres_text" value="<?php echo esc_attr( $genres_text ); ?>">
         <small>Comma-separated list, e.g., Action, Sci-Fi, Thriller. This is filled automatically by the fetcher.</small>
    </div>
     <div class="sam-meta-field">
        <label for="sam_synopsis">Synopsis</label>
        <textarea id="sam_synopsis" name="sam_synopsis" rows="5"><?php echo esc_textarea( $synopsis ); ?></textarea>
    </div>

    <hr>
    <h3 style="margin-bottom: 5px;">For Movies:</h3>

    <div class="sam-meta-field">
        <label for="sam_torrent_titles">Torrent Titles</label>
        <textarea id="sam_torrent_titles" name="sam_torrent_titles" rows="5"><?php echo esc_textarea( $torrent_titles ); ?></textarea>
        <small>Enter one title per line (e.g., 1080p BluRay). Make sure it matches the order of the magnet links below.</small>
    </div>
    <div class="sam-meta-field">
        <label for="sam_magnet_links">Magnet Links</label>
        <textarea id="sam_magnet_links" name="sam_magnet_links" rows="5"><?php echo esc_textarea( $magnet_links ); ?></textarea>
        <small>Enter one full magnet link per line. The number of lines here MUST match the number of lines in Torrent Titles.</small>
    </div>

    <hr>
    <h3 style="margin-bottom: 5px;">For TV Shows:</h3>

    <div class="sam-meta-field">
        <label for="sam_torrents_data">Torrents Data</label>
        <textarea id="sam_torrents_data" name="sam_torrents_data" rows="8"><?php echo esc_textarea( $torrents_data ); ?></textarea>
        <small>Enter one torrent per line. Format: S##E## | Quality | Size | magnet:link... (Use S##PACK for season packs)</small>
    </div>
    <?php
}

add_action( 'save_post', 'sam_save_media_details_meta_data' );
/**
 * Saves the custom meta data when a post is saved.
 *
 * @param int $post_id The post ID.
 */
function sam_save_media_details_meta_data( $post_id ) {
    // 1. Check nonce for security.
    if ( ! isset( $_POST['sam_media_details_nonce'] ) || ! wp_verify_nonce( $_POST['sam_media_details_nonce'], 'sam_save_media_details' ) ) {
        return;
    }

    // 2. Don't save on autosave.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // 3. Check user permissions.
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    // 4. Define our fields.
    $fields = [
        'sam_year'           => 'sanitize_text_field',
        'sam_rating'         => 'sanitize_text_field',
        'sam_backdrop_path'  => 'sanitize_text_field',
        'sam_tmdb_id'        => 'sanitize_text_field',
        'sam_genres_text'    => 'sanitize_text_field',
        'sam_synopsis'       => 'sanitize_textarea_field',
        'sam_torrent_titles' => 'sanitize_textarea_field',
        'sam_magnet_links'   => 'sanitize_textarea_field',
        'sam_torrents_data'  => 'sanitize_textarea_field',
    ];

    // 5. Loop through fields, sanitize, and save.
    foreach ( $fields as $key => $sanitize_callback ) {
        if ( isset( $_POST[ $key ] ) ) {
            $value = call_user_func( $sanitize_callback, $_POST[ $key ] );
            update_post_meta( $post_id, '_' . $key, $value ); // Note the underscore added to the key
        }
    }
}





/*
|--------------------------------------------------------------------------
| 17. FORM ENTRY HANDLING (CPT & META BOXES)
|--------------------------------------------------------------------------
|
| Replaces email notifications with a dashboard-based entry system
| using Custom Post Types (CPTs) for Submissions and Requests.
|
*/

add_action( 'init', 'sam_register_entry_post_types' );
/**
 * Registers the 'Submission' and 'Request' Custom Post Types.
 */
function sam_register_entry_post_types() {
    // CPT for Contact Form Submissions
    register_post_type( 'submission', [
        'labels'        => [ 'name' => 'Submissions', 'singular_name' => 'Submission', 'menu_name' => 'Inbox' ],
        'public'        => false, // Not publicly viewable
        'show_ui'       => true,  // Show in the admin dashboard
        'menu_icon'     => 'dashicons-email-alt',
        'supports'      => [ 'title' ], // We only use the title field for the sender's name
        'capability_type' => 'post',
        'show_in_menu'  => true,
    ]);

    // CPT for Movie/TV Requests
    register_post_type( 'request', [
        'labels'        => [ 'name' => 'Requests', 'singular_name' => 'Request' ],
        'public'        => false, // Not publicly viewable
        'show_ui'       => true,  // Show in the admin dashboard
        'menu_icon'     => 'dashicons-lightbulb',
        'supports'      => [ 'title' ], // We only use the title field for the requested movie title
        'capability_type' => 'post',
        'show_in_menu'  => true,
    ]);
}

add_action( 'add_meta_boxes', 'sam_add_entry_viewer_meta_box' );
/**
 * Registers the meta box to display the entry details.
 */
function sam_add_entry_viewer_meta_box() {
    $screens = [ 'submission', 'request' ]; // Add this to both CPTs
    foreach ( $screens as $screen ) {
        add_meta_box(
            'sam_entry_details_viewer',
            'Entry Details',
            'sam_render_entry_viewer_meta_box',
            $screen,
            'normal',
            'high'
        );
    }
}

/**
 * Renders the HTML for the entry viewer meta box (read-only).
 * @param WP_Post $post The post object.
 */
function sam_render_entry_viewer_meta_box( $post ) {
    echo '<style> .entry-detail { margin-bottom: 20px; } .entry-detail h4 { margin: 0 0 5px 0; font-size: 14px; color: #555; } .entry-detail p { margin: 0; font-size: 16px; background: #f9f9f9; padding: 10px; border-left: 3px solid #0073aa; } </style>';

    if ( get_post_type( $post ) === 'submission' ) {
        // Display details for a Contact Submission
        $email   = get_post_meta( $post->ID, '_sender_email', true );
        $message = get_post_meta( $post->ID, '_sender_message', true );
        ?>
        <div class="entry-detail">
            <h4>Sender's Email</h4>
            <p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
        </div>
        <div class="entry-detail">
            <h4>Message</h4>
            <p><?php echo nl2br( esc_html( $message ) ); ?></p>
        </div>
        <?php
    } elseif ( get_post_type( $post ) === 'request' ) {
        // Display details for a Media Request
        $year  = get_post_meta( $post->ID, '_request_year', true );
        $notes = get_post_meta( $post->ID, '_request_notes', true );
        ?>
        <div class="entry-detail">
            <h4>Year of Release</h4>
            <p><?php echo esc_html( $year ); ?></p>
        </div>
        <div class="entry-detail">
            <h4>Additional Notes</h4>
            <p><?php echo nl2br( esc_html( $notes ) ); ?></p>
        </div>
        <?php
    }
}

// --- Custom Admin Columns for "Submissions" ---
add_filter( 'manage_submission_posts_columns', 'sam_set_submission_columns' );
function sam_set_submission_columns( $columns ) {
    return [
        'cb' => $columns['cb'],
        'title' => __( 'Sender Name' ),
        'sender_email' => __( 'Sender Email' ),
        'date' => $columns['date'],
    ];
}

add_action( 'manage_submission_posts_custom_column', 'sam_fill_submission_columns', 10, 2 );
function sam_fill_submission_columns( $column, $post_id ) {
    if ( 'sender_email' === $column ) {
        $email = get_post_meta( $post_id, '_sender_email', true );
        echo esc_html( $email );
    }
}

// --- Custom Admin Columns for "Requests" ---
add_filter( 'manage_request_posts_columns', 'sam_set_request_columns' );
function sam_set_request_columns( $columns ) {
    return [
        'cb' => $columns['cb'],
        'title' => __( 'Requested Title' ),
        'request_year' => __( 'Year' ),
        'date' => $columns['date'],
    ];
}

add_action( 'manage_request_posts_custom_column', 'sam_fill_request_columns', 10, 2 );
function sam_fill_request_columns( $column, $post_id ) {
    if ( 'request_year' === $column ) {
        $year = get_post_meta( $post_id, '_request_year', true );
        echo esc_html( $year );
    }
}









/*
|--------------------------------------------------------------------------
| 18. CENTRALIZED FORM SUBMISSION HANDLERS
|--------------------------------------------------------------------------
|
| Handles form submissions via admin-post.php to ensure logic always runs.
| This is the correct, robust way to handle front-end forms.
|
*/

// --- Handler for the Contact Form ---
add_action( 'admin_post_sam_contact_form', 'sam_handle_contact_submission' );
add_action( 'admin_post_nopriv_sam_contact_form', 'sam_handle_contact_submission' ); // For logged-out users

function sam_handle_contact_submission() {
    // 1. Check for the redirect URL
    $redirect_url = isset( $_POST['redirect_url'] ) ? esc_url_raw( $_POST['redirect_url'] ) : home_url();

    // 2. Verify nonce and honeypot
    if ( ! isset( $_POST['contact_form_nonce'] ) || ! wp_verify_nonce( $_POST['contact_form_nonce'], 'submit_contact_form_action' ) ) {
        wp_safe_redirect( add_query_arg( 'status', 'nonce_fail', $redirect_url ) ); exit;
    }
    if ( ! empty( $_POST['website_url'] ) ) { // Honeypot check
        wp_safe_redirect( add_query_arg( 'status', 'success', $redirect_url ) ); exit;
    }

    // 3. Sanitize data
    $name    = sanitize_text_field( $_POST['name'] );
    $email   = sanitize_email( $_POST['email'] );
    $message = sanitize_textarea_field( $_POST['message'] );

    if ( ! is_email( $email ) ) {
        wp_safe_redirect( add_query_arg( 'status', 'email_fail', $redirect_url ) ); exit;
    }

    // 4. Create the post
    $post_id = wp_insert_post([
        'post_title'  => $name,
        'post_type'   => 'submission',
        'post_status' => 'publish',
    ]);

    if ( $post_id && ! is_wp_error( $post_id ) ) {
        update_post_meta( $post_id, '_sender_email', $email );
        update_post_meta( $post_id, '_sender_message', $message );
        wp_safe_redirect( add_query_arg( 'status', 'success', $redirect_url ) ); exit;
    } else {
        wp_safe_redirect( add_query_arg( 'status', 'error', $redirect_url ) ); exit;
    }
}


// --- Handler for the Request Form ---
add_action( 'admin_post_sam_request_form', 'sam_handle_request_submission' );
add_action( 'admin_post_nopriv_sam_request_form', 'sam_handle_request_submission' ); // For logged-out users

function sam_handle_request_submission() {
    // 1. Check for the redirect URL
    $redirect_url = isset( $_POST['redirect_url'] ) ? esc_url_raw( $_POST['redirect_url'] ) : home_url();

    // 2. Verify nonce and honeypot
    if ( ! isset( $_POST['request_form_nonce'] ) || ! wp_verify_nonce( $_POST['request_form_nonce'], 'submit_request_form_action' ) ) {
        wp_safe_redirect( add_query_arg( 'status', 'nonce_fail', $redirect_url ) ); exit;
    }
    if ( ! empty( $_POST['user_nickname'] ) ) { // Honeypot check
        wp_safe_redirect( add_query_arg( 'status', 'success', $redirect_url ) ); exit;
    }

    // 3. Sanitize data
    $movie_title = sanitize_text_field( $_POST['movie_title'] );
    $year        = sanitize_text_field( $_POST['year'] );
    $notes       = sanitize_textarea_field( $_POST['notes'] );

    // 4. Create the post
    $post_id = wp_insert_post([
        'post_title'  => $movie_title,
        'post_type'   => 'request',
        'post_status' => 'publish',
    ]);

    if ( $post_id && ! is_wp_error( $post_id ) ) {
        update_post_meta( $post_id, '_request_year', $year );
        update_post_meta( $post_id, '_request_notes', $notes );
        wp_safe_redirect( add_query_arg( 'status', 'success', $redirect_url ) ); exit;
    } else {
        wp_safe_redirect( add_query_arg( 'status', 'error', $redirect_url ) ); exit;
    }
}








add_action('admin_enqueue_scripts', 'sam_enqueue_color_picker');
/**
 * Enqueues the WordPress color picker style and script.
 *
 * @param string $hook_suffix The current admin page.
 */
function sam_enqueue_color_picker($hook_suffix) {
    // Only load on our theme options page
    if ('toplevel_page_sam_theme_options' !== $hook_suffix) {
        return;
    }
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('sam-theme-options-script', get_template_directory_uri() . '/js/theme-options.js', ['wp-color-picker'], false, true);
}



/*
|--------------------------------------------------------------------------
| 19. PROFESSIONAL THEME OPTIONS PANEL
|--------------------------------------------------------------------------
|
| Creates a dedicated "Theme Options" page in the admin menu to
| manage all theme settings, replacing the Customizer.
|
*/

add_action('admin_menu', 'sam_add_theme_options_page');
/**
 * Adds the "Theme Options" page to the admin menu.
 */
function sam_add_theme_options_page() {
    add_menu_page(
        'Theme Options',      // Page Title
        'Theme Options',      // Menu Title
        'manage_options',     // Capability required
        'sam_theme_options',  // Menu Slug
        'sam_render_theme_options_page', // Function to render the page
        'dashicons-admin-settings', // Icon
        60                    // Position in menu
    );
}

/**
 * Renders the HTML for the theme options page.
 */
function sam_render_theme_options_page() {
    ?>
    <div class="wrap">
        <h1>Theme Options</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('sam_options_group'); // Outputs nonce, action, and option_page fields for our settings group.
            do_settings_sections('sam_theme_options'); // Renders the sections and fields for the page.
            submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'sam_register_theme_settings');
/**
 * Registers the settings, sections, and fields for the options page.
 */
function sam_register_theme_settings() {
    // Register the main setting. This will store all our options in a single array in the database.
    register_setting('sam_options_group', 'sam_theme_options_data', [
        'sanitize_callback' => 'sam_sanitize_options'
    ]);

    // Section 1: API Settings
    add_settings_section('sam_api_settings_section', 'API Settings', null, 'sam_theme_options');
    
    add_settings_field('sam_tmdb_api_key', 'TMDB API Key', 'sam_render_tmdb_api_key_field', 'sam_theme_options', 'sam_api_settings_section');


    // Section: Download Page Settings
    add_settings_section('sam_download_page_section', 'Intermediate Download Page', null, 'sam_theme_options');

    add_settings_field('sam_enable_intermediate_page', 'Enable Download Page', 'sam_render_checkbox_field', 'sam_theme_options', 'sam_download_page_section', ['id' => 'enable_intermediate_page', 'description' => 'If checked, download links will go to a separate page. If unchecked, links will be copied directly as before.']);
    add_settings_field('sam_link_delay_timer', 'Link Delay Timer (seconds)', 'sam_render_number_field', 'sam_theme_options', 'sam_download_page_section', ['id' => 'link_delay_timer', 'default' => 5, 'description' => 'The time a user must wait on the download page before the link appears. Set to 0 for no delay.']);



    
    // Section: Styling Settings
    add_settings_section('sam_styling_settings_section', 'Styling Settings', null, 'sam_theme_options');

    add_settings_field('sam_accent_color', 'Accent Color', 'sam_render_color_picker_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'accent_color', 'default' => '#bb86fc']);
    add_settings_field('sam_primary_bg_color', 'Primary Background Color', 'sam_render_color_picker_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'primary_bg', 'default' => '#121212']);
    add_settings_field('sam_secondary_bg_color', 'Secondary Background Color', 'sam_render_color_picker_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'secondary_bg', 'default' => '#1e1e1e']);
    add_settings_field('sam_primary_text_color', 'Primary Text Color', 'sam_render_color_picker_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'primary_text', 'default' => '#e0e0e0']);
    add_settings_field('sam_body_font', 'Body Font', 'sam_render_font_select_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'body_font']);
    add_settings_field('sam_enable_hamburger_menu', 'Enable Hamburger Menu on Mobile', 'sam_render_checkbox_field', 'sam_theme_options', 'sam_styling_settings_section', ['id' => 'enable_hamburger_menu', 'description' => 'If checked, a hamburger icon will be used for the main menu on mobile screens (768px and below). The desktop view will remain a full menu.']);



    // Section 2: Movie Hub Titles
    add_settings_section('sam_movie_hub_section', 'Movie Hub Section Titles', null, 'sam_theme_options');
    
    add_settings_field('sam_movies_recent_title', 'Recent Movies Title', 'sam_render_text_field', 'sam_theme_options', 'sam_movie_hub_section', ['id' => 'movies_hub_recent_title', 'default' => 'Recently Added']);
    add_settings_field('sam_movies_trending_title', 'Trending Movies Title', 'sam_render_text_field', 'sam_theme_options', 'sam_movie_hub_section', ['id' => 'movies_hub_trending_title', 'default' => 'Trending Movies']);
    add_settings_field('sam_movies_2025_title', '2025 Movies Title', 'sam_render_text_field', 'sam_theme_options', 'sam_movie_hub_section', ['id' => 'movies_hub_2025_title', 'default' => 'Movies of 2025']);
    add_settings_field('sam_movies_top_rated_title', 'Top Rated Movies Title', 'sam_render_text_field', 'sam_theme_options', 'sam_movie_hub_section', ['id' => 'movies_hub_top_rated_title', 'default' => 'Top Rated of All Time']);

    // Section 3: TV Hub Titles
    add_settings_section('sam_tv_hub_section', 'TV Hub Section Titles', null, 'sam_theme_options');
    
    add_settings_field('sam_tv_airing_title', 'Airing/2025 Title', 'sam_render_text_field', 'sam_theme_options', 'sam_tv_hub_section', ['id' => 'tv_hub_airing_title', 'default' => 'Upcoming Shows (2025)']);
    add_settings_field('sam_tv_top_rated_title', 'Top Rated Title', 'sam_render_text_field', 'sam_theme_options', 'sam_tv_hub_section', ['id' => 'tv_hub_top_rated_title', 'default' => 'Top-Rated Sci-Fi & Fantasy']);
    add_settings_field('sam_tv_netflix_title', 'Netflix Title', 'sam_render_text_field', 'sam_theme_options', 'sam_tv_hub_section', ['id' => 'tv_hub_netflix_title', 'default' => 'Netflix Originals']);
    add_settings_field('sam_tv_hbo_title', 'HBO Title', 'sam_render_text_field', 'sam_theme_options', 'sam_tv_hub_section', ['id' => 'tv_hub_hbo_title', 'default' => 'HBO Originals']);
    add_settings_field('sam_tv_action_title', 'Action Title', 'sam_render_text_field', 'sam_theme_options', 'sam_tv_hub_section', ['id' => 'tv_hub_action_title', 'default' => 'Action & Adventure']);



        // Section 5: Ad Management
    add_settings_section('sam_ad_management_section', 'Ad Management', null, 'sam_theme_options');
    
    add_settings_field('sam_ad_header', 'Header Ad', 'sam_render_textarea_field', 'sam_theme_options', 'sam_ad_management_section', ['id' => 'ad_header', 'description' => 'Appears below the header on all pages. Recommended size: 728x90.']);
    add_settings_field('sam_ad_archive', 'Archive Ad', 'sam_render_textarea_field', 'sam_theme_options', 'sam_ad_management_section', ['id' => 'ad_archive', 'description' => 'Appears below the content grid on movie/TV/actor archive pages.']);
    add_settings_field('sam_ad_single', 'Single Post Ad', 'sam_render_textarea_field', 'sam_theme_options', 'sam_ad_management_section', ['id' => 'ad_single', 'description' => 'Appears on movie/TV show pages, just above the download links section.']);
    add_settings_field('sam_ad_download', 'Download Page Ad', 'sam_render_textarea_field', 'sam_theme_options', 'sam_ad_management_section', ['id' => 'ad_download', 'description' => 'Appears in the middle of the intermediate download page.']);

}

/**
 * Renders the input field for the TMDB API Key.
 */
function sam_render_tmdb_api_key_field() {
    $options = get_option('sam_theme_options_data');
    $api_key = isset($options['tmdb_api_key']) ? $options['tmdb_api_key'] : '';
    echo '<input type="text" name="sam_theme_options_data[tmdb_api_key]" value="' . esc_attr($api_key) . '" size="50">';
    echo '<p class="description">Please paste your own API key here. Don\'t have a key? <a href="https://www.themoviedb.org/documentation/api" target="_blank">Get a TMDB API key</a>.</p>';
}

/**
 * Renders a generic text field.
 * @param array $args Arguments containing the field ID and default value.
 */
function sam_render_text_field($args) {
    $options = get_option('sam_theme_options_data');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : $args['default'];
    echo '<input type="text" name="sam_theme_options_data[' . esc_attr($args['id']) . ']" value="' . esc_attr($value) . '" size="50">';
}



/**
 * Renders a color picker field.
 * @param array $args Arguments containing the field ID and default value.
 */
function sam_render_color_picker_field($args) {
    $options = get_option('sam_theme_options_data');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : $args['default'];
    echo '<input type="text" name="sam_theme_options_data[' . esc_attr($args['id']) . ']" value="' . esc_attr($value) . '" class="sam-color-picker" data-default-color="' . esc_attr($args['default']) . '">';
}

/**
 * Renders a font selection dropdown.
 * @param array $args Arguments containing the field ID.
 */
function sam_render_font_select_field($args) {
    $options = get_option('sam_theme_options_data');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : 'System UI';
    $fonts = [
        'System UI' => 'System Default',
        'Roboto' => 'Roboto',
        'Open Sans' => 'Open Sans',
        'Lato' => 'Lato',
        'Montserrat' => 'Montserrat',
        'Source Sans Pro' => 'Source Sans Pro'
    ];
    echo '<select name="sam_theme_options_data[' . esc_attr($args['id']) . ']">';
    foreach ($fonts as $font_value => $font_name) {
        echo '<option value="' . esc_attr($font_value) . '" ' . selected($value, $font_value, false) . '>' . esc_html($font_name) . '</option>';
    }
    echo '</select>';
}



/**
 * Renders a checkbox field.
 * @param array $args Arguments containing the field ID and description.
 */
function sam_render_checkbox_field($args) {
    $options = get_option('sam_theme_options_data');
    $checked = isset($options[$args['id']]) && $options[$args['id']] == '1' ? 'checked' : '';
    echo '<input type="checkbox" name="sam_theme_options_data[' . esc_attr($args['id']) . ']" value="1" ' . $checked . '>';
    echo '<p class="description">' . esc_html($args['description']) . '</p>';
}

/**
 * Renders a number input field.
 * @param array $args Arguments containing the field ID, default, and description.
 */
function sam_render_number_field($args) {
    $options = get_option('sam_theme_options_data');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : $args['default'];
    echo '<input type="number" name="sam_theme_options_data[' . esc_attr($args['id']) . ']" value="' . esc_attr($value) . '" min="0" max="60">';
    echo '<p class="description">' . esc_html($args['description']) . '</p>';
}


/**
 * Renders a generic textarea field, perfect for ad code.
 * @param array $args Arguments containing the field ID and description.
 */
function sam_render_textarea_field($args) {
    $options = get_option('sam_theme_options_data');
    $value = isset($options[$args['id']]) ? $options[$args['id']] : '';
    echo '<textarea name="sam_theme_options_data[' . esc_attr($args['id']) . ']" rows="5" cols="50" style="width:100%;">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">' . esc_html($args['description']) . '</p>';
}


/**
 * Sanitizes the options array before saving to the database.
 * @param array $input The raw input from the form.
 * @return array The sanitized input.
 */
function sam_sanitize_options($input) {
    $sanitized_input = [];
    $font_choices = ['System UI', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Source Sans Pro'];


    // --- Ad Code Sanitization ---
    // We allow script and iframe tags here, as they are necessary for ad code.
    // This is safe because only administrators can access the theme options panel.
    $ad_fields = ['ad_header', 'ad_archive', 'ad_single', 'ad_download'];
    foreach ($ad_fields as $field) {
        if (isset($input[$field])) {
            $sanitized_input[$field] = $input[$field]; // Save the raw code
        }
    }

    // Sanitize Checkbox (it will only be set if checked)
    $sanitized_input['enable_intermediate_page'] = isset($input['enable_intermediate_page']) ? '1' : '0';

    $sanitized_input['enable_hamburger_menu'] = isset($input['enable_hamburger_menu']) ? '1' : '0';

    // Sanitize Number Field
    if (isset($input['link_delay_timer'])) {
        $sanitized_input['link_delay_timer'] = absint($input['link_delay_timer']); // Ensures it's a positive integer
    }

    // Sanitize API Key
    if (isset($input['tmdb_api_key'])) { $sanitized_input['tmdb_api_key'] = sanitize_text_field($input['tmdb_api_key']); }

    // Sanitize Color Fields
    $color_fields = ['accent_color', 'primary_bg', 'secondary_bg', 'primary_text'];
    foreach ($color_fields as $field) { if (isset($input[$field]) && preg_match('/^#[a-f0-9]{6}$/i', $input[$field])) { $sanitized_input[$field] = $input[$field]; } }

    // Sanitize Font Field
    if (isset($input['body_font']) && in_array($input['body_font'], $font_choices)) { $sanitized_input['body_font'] = $input['body_font']; }

    // Sanitize all other text fields
    $text_fields = ['movies_hub_recent_title', 'movies_hub_trending_title', 'movies_hub_2025_title', 'movies_hub_top_rated_title', 'tv_hub_airing_title', 'tv_hub_top_rated_title', 'tv_hub_netflix_title', 'tv_hub_hbo_title', 'tv_hub_action_title'];
    foreach ($text_fields as $field) { if (isset($input[$field])) { $sanitized_input[$field] = sanitize_text_field($input[$field]); } }
    return $sanitized_input;
}






add_action('wp_head', 'sam_output_dynamic_styles');
/**
 * Outputs the dynamic CSS to the <head> of the site.
 */
function sam_output_dynamic_styles() {
    global $sam_theme_options;
    $options = $sam_theme_options;

    // Early exit if no options are set
    if (empty($options)) {
        return;
    }

    $css = '';

    // --- Font Handling ---
    $font_family = $options['body_font'] ?? 'System UI';
    if ($font_family !== 'System UI') {
        // Enqueue Google Font
        $font_query_arg = str_replace(' ', '+', $font_family);
        wp_enqueue_style('sam-google-font', "https://fonts.googleapis.com/css2?family={$font_query_arg}:wght@400;700&display=swap", [], null);
        
        // Add font-family to CSS
        $css .= "body, html { font-family: '{$font_family}', sans-serif; }\n";
    }

    // --- Color Handling ---
    $css_vars = '';
    $colors = [
        'accent-color' => 'accent_color',
        'primary-bg' => 'primary_bg',
        'secondary-bg' => 'secondary_bg',
        'primary-text' => 'primary_text'
    ];
    
    foreach ($colors as $css_var => $option_key) {
        if (!empty($options[$option_key])) {
            $css_vars .= "--{$css_var}: " . esc_attr($options[$option_key]) . ";\n";
        }
    }

    if (!empty($css_vars)) {
        $css .= ":root {\n" . $css_vars . "}\n";
    }
    
    // --- Output Final CSS ---
    if (!empty($css)) {
        echo '<style type="text/css" id="sam-dynamic-styles">' . $css . '</style>';
    }
}



add_action('wp_head', 'sam_add_download_link_styles');
/**
 * Adds all necessary custom CSS for download page and button functionality.
 */
function sam_add_download_link_styles() {
    echo '<style type="text/css" id="sam-dynamic-styles-fix">
        /*
         * FIX FOR STRETCHED MOVIE BUTTONS:
         * This makes the movie link container a flex container and aligns its
         * children (the buttons) to the start, preventing them from stretching.
         */
        .torrent-links-container {
            display: flex;
            flex-direction: column;
            align-items: stretch; /* Default, but good to be explicit */
            gap: 0.5rem; /* Adds space between the buttons */
        }
        
        .torrent-links-container > a.copy-magnet-button {
            flex-grow: 0; /* Prevents the item from growing */
            align-self: center; /* Centers the button within the column */
        }

        /* General fix for link decoration on all download buttons */
        a.copy-magnet-button {
            text-decoration: none;
        }

        /* Styles the container for the new ad widget */
        .download-ad-container {
            margin: 2rem 0;
            padding: 1rem;
            background: var(--secondary-bg);
            border-radius: 8px;
        }
        .download-ad-container .widget {
            margin: 0;
            padding: 0;
        }

        /* Styles the magnet link input field on the download page */
        #magnet_link_field {
            width: 100%;
            background-color: var(--primary-bg);
            color: var(--primary-text);
            border: 1px solid var(--card-border);
            border-color: var(--accent-color);
            border-radius: 5px;
            padding: 0.75rem;
            font-size: 1rem;
            box-sizing: border-box;
            text-align: center;
            transition: border-color 0.2s ease;
        }

        /* NEW: Adds the accent color on focus to the input field */
        #magnet_link_field:focus {
            border-color: var(--accent-color);
            outline: none;
        }


        /*
         * NEW: FIX FOR ACTOR LINK STYLING
         * Ensures clickable actor names look consistent with non-clickable ones.
         */
        .cast-list a.cast-member-name {
            color: var(--primary-text); /* Use the main text color, not the link color */
            text-decoration: none;   /* Remove the default underline */
            transition: color 0.2s ease; /* Add a smooth transition for the hover effect */
        }

        /* NEW: Adds a hover effect to show the link is clickable */
        .cast-list a.cast-member-name:hover {
            color: var(--accent-color); /* Change color on hover to your themes accent color */
        }


        /*
         * NEW: HEADER MENU HOVER & ACTIVE STYLES
         */
        .header-nav .header-menu li a {
            transition: color 0.2s ease;
        }
        .header-nav .header-menu li a:hover,
        .header-nav .header-menu li.current-menu-item > a,
        .header-nav .header-menu li.current-page-ancestor > a {
            color: var(--accent-color); /* Use the themes accent color on hover/active */
        }



        /* --- NEW RESPONSIVE FIXES --- */
        @media (max-width: 768px) {
            /* 1. FIX: Responsive "Browse More" Button */
            .hub-section-header {
                flex-wrap: wrap; /* Allows items to wrap to the next line */
                gap: 1rem; /* Adds space between the title and the button when wrapped */
            }
            .hub-section-title {
                flex-basis: 100%; /* Makes the title take the full width on its own line */
            }

            /* 2. FIX: Hide Sidebar on Mobile */
            .sidebar-column {
                display: none !important; /* Completely hides the sidebar on mobile */
            }
            .single-page-layout {
                flex-direction: row; /* Overrides the previous stacking behavior */
            }
        }

/* --- FINAL RESPONSIVE & HAMBURGER STYLES --- */

        /* DESKTOP First (Default Layout) */
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1.5rem; }
        .menu-toggle { display: none; } /* Hamburger is ALWAYS hidden on desktop */

        /* MOBILE Styles (768px and below) */
        @media (max-width: 768px) {
            /* Default mobile layout (no hamburger) */
            .header { flex-direction: column; }
            .search-form { order: 1; width: 100%; max-width: none; }
            .header-nav { order: 2; }

            /* Styles ONLY for when the Hamburger Menu option is ENABLED */
            .mobile-hamburger-enabled .header {
                flex-direction: row; /* Puts items on one line */
                flex-wrap: wrap; /* Allows search bar to wrap to the next line */
                justify-content: space-between; /* Pushes Logo and Toggle to the edges */
            }
            .mobile-hamburger-enabled .header-title { flex-grow: 1; } /* Allows title to take available space */
            .mobile-hamburger-enabled .header-nav {
                /* This is the slide-out panel */
                order: 4; /* Places it last in the flex order */
                position: fixed; top: 0; right: 0;
                width: 300px; height: 100vh;
                background: var(--secondary-bg);
                flex-direction: column; justify-content: center; align-items: center; gap: 2rem;
                transform: translateX(100%); /* Hides it off-screen */
                transition: transform 0.3s ease-in-out;
                z-index: 1000;
            }
            .mobile-hamburger-enabled .header-nav.is-toggled {
                transform: translateX(0); /* Slides it into view */
            }
            .mobile-hamburger-enabled .header-nav .header-menu { flex-direction: column; }

            .mobile-hamburger-enabled .search-form {
                order: 3; /* Places it below the top row */
                flex-basis: 100%; /* Makes it take the full width on its own line */
                margin-top: 1.5rem;
            }
            
            .mobile-hamburger-enabled .menu-toggle {
                display: flex; /* Shows the hamburger icon */
                order: 2; /* Puts it after the logo */
                background: none; border: none; cursor: pointer; flex-direction: column; gap: 5px; padding: 0; z-index: 1001;
            }
            .mobile-hamburger-enabled .menu-toggle .line { width: 25px; height: 3px; background-color: var(--primary-text); border-radius: 3px; transition: all 0.3s ease; }
            .mobile-hamburger-enabled .menu-toggle.is-active .line:nth-child(1) { transform: translateY(8px) rotate(45deg); }
            .mobile-hamburger-enabled .menu-toggle.is-active .line:nth-child(2) { opacity: 0; }
            .mobile-hamburger-enabled .menu-toggle.is-active .line:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }

            /* Hides the sidebar on all mobile views */
            .sidebar-column { display: none !important; }
        }

        /* --- AD CONTAINER STYLES --- */
        .ad-container { margin: 2rem auto; text-align: center; }
        .ad-container--ad_header { margin-top: 0; }
        .ad-container img, .ad-container iframe { max-width: 100%; height: auto; }

    </style>';
}












/*
|--------------------------------------------------------------------------
| 21. COMPLETE THEME ACTIVATION SETUP
|--------------------------------------------------------------------------
|
| This function runs only once when the theme is activated. It creates
| all necessary pages, sets the front page, creates and configures all three
| navigation menus, and places the sidebar widgets automatically.
| This provides a complete "one-click" setup experience.
|
*/
add_action('after_switch_theme', 'sam_complete_theme_activation_setup');

function sam_complete_theme_activation_setup() {

    // --- 1. Define All Pages, Menus, and Content ---

    $dmca_content = "Sam Torrent Hub respects the intellectual property rights of others and expects its users to do the same. This site is a torrent search engine that indexes magnet links from various sources; no copyrighted files are stored on our servers. In accordance with the Digital Millennium Copyright Act of 1998, the text of which may be found on the U.S. Copyright Office website at http://www.copyright.gov/legislation/dmca.pdf, Sam Torrent Hub will respond expeditiously to claims of copyright infringement... [IMPORTANT: Paste your full DMCA text here]";
    $contact_content = "If you have any questions, feedback, or concerns, please fill out the form below to get in touch with our team. We'll do our best to respond as quickly as possible.";
    $request_content = "Can't find what you're looking for? Let us know the title and year of the content you'd like to see on the site, and we'll do our best to find it.";

    $pages_to_create = [
        ['title' => 'Movies', 'slug' => 'discover-movies', 'template' => 'page-movies.php', 'content' => ''],
        ['title' => 'TV Shows', 'slug' => 'discover-tv', 'template' => 'page-tv-shows.php', 'content' => ''],
        ['title' => 'DMCA', 'slug' => 'dmca', 'template' => 'page-dmca.php', 'content' => $dmca_content],
        ['title' => 'Movie Request', 'slug' => 'movie-request', 'template' => 'page-request.php', 'content' => $request_content],
        ['title' => 'Contact Us', 'slug' => 'contact-us', 'template' => 'page-contact.php', 'content' => $contact_content],
    ];

    $movie_sidebar_links = [
        'Recently Added' => home_url('/movies/recent/'),
        '2025 & Upcoming' => home_url('/movies/year/2025/'),
        'Trending Movies' => home_url('/movies/trending/'),
        'Top Rated' => home_url('/movies/top-rated/'),
    ];

    $tv_sidebar_links = [
        'Currently Airing' => home_url('/tv/airing/'),
        'Top Rated' => home_url('/tv/top-rated/'),
        'Netflix' => home_url('/tv/network/netflix/'),
        'HBO' => home_url('/tv/network/hbo/'),
        'Sci-Fi & Action' => home_url('/tv/genre/sci-fi-action/'),
    ];

    $created_page_ids = [];

    // --- 2. Create Pages if they don't exist ---
    foreach ($pages_to_create as $page_def) {
        $existing_page = get_page_by_path($page_def['slug']);
        if (!$existing_page) {
            $page_id = wp_insert_post(['post_title' => $page_def['title'], 'post_name' => $page_def['slug'], 'post_content' => $page_def['content'], 'post_status' => 'publish', 'post_type' => 'page']);
            if ($page_id && !is_wp_error($page_id)) {
                update_post_meta($page_id, '_wp_page_template', $page_def['template']);
                $created_page_ids[$page_def['title']] = $page_id;
            }
        } else {
            $created_page_ids[$page_def['title']] = $existing_page->ID;
        }
    }

    // --- 3. Set the Front Page ---
    if (isset($created_page_ids['Movies'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_page_ids['Movies']);
    }

    // --- 4. Create and Assign Menus ---
    $header_menu_id = sam_setup_create_menu('Header Menu', $created_page_ids, ['Movies', 'TV Shows', 'DMCA', 'Movie Request', 'Contact Us']);
    $movie_sidebar_menu_id = sam_setup_create_menu('Movie Sidebar Links', $movie_sidebar_links);
    $tv_sidebar_menu_id = sam_setup_create_menu('TV Show Sidebar Links', $tv_sidebar_links);

    // Assign Header Menu to the 'primary' location
    if ($header_menu_id) {
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $header_menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }

    // --- 5. Programmatically Add and Configure ALL Widgets ---
    $sidebars_widgets = get_option('sidebars_widgets', []);
    
    // Clear out any default widgets WordPress might have added to our sidebars
    $sidebars_widgets['sidebar-global'] = [];
    $sidebars_widgets['sidebar-movie'] = [];
    $sidebars_widgets['sidebar-tv'] = [];
    $sidebars_widgets['sidebar-download-ad'] = [];

    // Get the settings for the widgets we will use
    $widget_nav_menu_settings = get_option('widget_nav_menu', []);
    $widget_search_settings = get_option('widget_search', []);
    $widget_html_settings = get_option('widget_custom_html', []);
    
    // Find the next available widget ID number
    $next_widget_id = 1;
    foreach ([$widget_nav_menu_settings, $widget_search_settings, $widget_html_settings] as $widget_group) {
        if (is_array($widget_group)) {
            foreach ($widget_group as $id => $settings) {
                if (is_int($id) && $id >= $next_widget_id) { $next_widget_id = $id + 1; }
            }
        }
    }
    
    // Add Global Search Widget
    $search_widget_id = $next_widget_id++;
    $sidebars_widgets['sidebar-global'] = ['search-' . $search_widget_id];
    $widget_search_settings[$search_widget_id] = ['title' => 'Search'];

    // Add Movie Sidebar Widget
    if ($movie_sidebar_menu_id) {
        $movie_widget_id = $next_widget_id++;
        $sidebars_widgets['sidebar-movie'] = ['nav_menu-' . $movie_widget_id];
        $widget_nav_menu_settings[$movie_widget_id] = ['title' => 'Browse Movies', 'nav_menu' => $movie_sidebar_menu_id];
    }

    // Add TV Show Sidebar Widget
    if ($tv_sidebar_menu_id) {
        $tv_widget_id = $next_widget_id++;
        $sidebars_widgets['sidebar-tv'] = ['nav_menu-' . $tv_widget_id];
        $widget_nav_menu_settings[$tv_widget_id] = ['title' => 'Browse TV Shows', 'nav_menu' => $tv_sidebar_menu_id];
    }

    // Add Placeholder HTML widget to Download Ad area
    $html_widget_id = $next_widget_id++;
    $sidebars_widgets['sidebar-download-ad'] = ['custom_html-' . $html_widget_id];
    $widget_html_settings[$html_widget_id] = ['title' => '', 'content' => '<!-- Your ad code will go here. Add from the Widgets panel. -->'];
    
    // Save all the updated widget settings
    update_option('sidebars_widgets', $sidebars_widgets);
    update_option('widget_nav_menu', $widget_nav_menu_settings);
    update_option('widget_search', $widget_search_settings);
    update_option('widget_custom_html', $widget_html_settings);
}

/**
 * Helper function for the setup process to create a menu if it doesn't exist.
 *
 * @param string $menu_name The name of the menu to create.
 * @param array $items Associative array of items to add. Keys are titles, values are URLs or post IDs.
 * @param array $page_titles (Optional) Ordered list of page titles for page-based menus.
 * @return int|null The ID of the created or found menu.
 */
function sam_setup_create_menu($menu_name, $items, $page_titles = []) {
    $menu_exists = wp_get_nav_menu_object($menu_name);
    if ($menu_exists) {
        return $menu_exists->term_id;
    }

    $menu_id = wp_create_nav_menu($menu_name);
    if (!$menu_id || is_wp_error($menu_id)) {
        return null;
    }

    if (!empty($page_titles)) { // It's a page-based menu
        foreach ($page_titles as $title) {
            if (isset($items[$title])) {
                wp_update_nav_menu_item($menu_id, 0, ['menu-item-title' => $title, 'menu-item-object' => 'page', 'menu-item-object-id' => $items[$title], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish']);
            }
        }
    } else { // It's a custom link menu
        foreach ($items as $title => $url) {
            wp_update_nav_menu_item($menu_id, 0, ['menu-item-title' => $title, 'menu-item-url' => $url, 'menu-item-status' => 'publish']);
        }
    }
    return $menu_id;
}



/**
 * Displays an ad from a specified theme option location.
 * The container will not be rendered if the ad code is empty.
 *
 * @param string $location The ID of the ad location (e.g., 'ad_header').
 */
function sam_display_ad($location) {
    global $sam_theme_options;
    $ad_code = $sam_theme_options[$location] ?? '';

    if (!empty(trim($ad_code))) {
        echo '<div class="ad-container ad-container--' . esc_attr($location) . '">';
        echo $ad_code; // Echoing raw ad code is intentional here
        echo '</div>';
    }
}







/*
|--------------------------------------------------------------------------
| 22. ONE-CLICK THEME UPDATER (Final, Robust, and Safe Version)
|--------------------------------------------------------------------------
|
| This is the definitive version. It runs on the standard 'init' hook
| but includes multiple safety checks to prevent fatal errors. It confirms
| the library file exists and the necessary class exists before attempting
| to initialize the updater. This is the correct, professional way.
|
*/
add_action('init', 'sam_setup_theme_updater');

function sam_setup_theme_updater() {
    // We only need the updater to run in the admin dashboard.
    if (!is_admin()) {
        return;
    }

    $updater_file = get_template_directory() . '/plugin-update-checker-master/plugin-update-checker.php';

    // First, check if the library file is actually there.
    if (file_exists($updater_file)) {
        
        require_once($updater_file);

        // --- THIS IS THE CRUCIAL FIX ---
        // Second, check if the main Factory class from the library has been loaded.
        // This prevents a fatal error if the file is corrupt or has a problem.
        if (class_exists('Puc_v4_Factory')) {
            
            $my_update_checker = Puc_v4_Factory::buildUpdateChecker(
                'https://sam-web-solutions.rf.gd/updates/info.json', // The URL to your info.json file
                get_template_directory(), // The path to your theme's root directory
                'sam-torrent-theme'       // The theme's folder name (slug)
            );

        }

    }
}






