<?php
/**
 * The template for displaying search results pages.
 * @package SamTorrentHub
 */
get_header(); 

$search_query = get_search_query();
?>

<h1 class="page-title">Search Results for "<?php echo esc_html($search_query); ?>"</h1>

<?php 
// --- Step 1: Query Local WordPress Database ---
$local_search_args = [
    'post_type'      => ['movie', 'tv_show'],
    'post_status'    => 'publish',
    's'              => $search_query,
    'posts_per_page' => 20,
];
$local_query = new WP_Query($local_search_args);
$local_tmdb_ids = [];

// --- Step 2: Query External APIs ---
$api_movies = search_yts_movies($search_query);
$api_shows  = search_tmdb_shows($search_query);

if ( ! empty( $api_movies ) || ! empty( $api_shows ) || $local_query->have_posts() ) : ?>
    <div class="movie-grid">

        <?php 
        // --- Display Local Results First ---
        if ( $local_query->have_posts() ) :
            while ( $local_query->have_posts() ) : $local_query->the_post(); 
                $post_id = get_the_ID();
                $post_type_label = get_post_type() === 'movie' ? 'Movie' : 'TV Show';
                // --- THIS IS THE FIX: Using get_post_meta instead of get_field ---
                $year = get_post_meta($post_id, '_sam_year', true);
                $local_tmdb_ids[] = get_post_meta($post_id, '_sam_tmdb_id', true);
                // --- END FIX ---
            ?>
                <a href="<?php the_permalink(); ?>" class="movie-card">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title_attribute(); ?>">
                    <?php else: ?>
                        <div class="placeholder-image"><span>🎬</span></div>
                    <?php endif; ?>
                    <div class="movie-card-info">
                        <h3 class="movie-card-title"><?php the_title(); ?></h3>
                        <p class="movie-card-year"><?php echo $post_type_label; ?> · <?php echo esc_html( $year ); ?></p>
                    </div>
                </a>
            <?php endwhile;
            wp_reset_postdata();
        endif; 
        ?>

        <?php 
        // --- Filter and Display API Movie Results ---
        if ( ! empty( $api_movies ) ) {
            foreach ( $api_movies as $movie ) {
                echo '<a href="'.esc_url(home_url('/movie/'.$movie['id'].'/'.sanitize_title($movie['title']))).'" class="movie-card">';
                echo '<img src="'.esc_url($movie['medium_cover_image']).'" alt="">';
                echo '<div class="movie-card-info"><h3 class="movie-card-title">'.esc_html($movie['title_long']).'</h3><p class="movie-card-year">Movie · '.esc_html($movie['year']).'</p></div>';
                echo '</a>';
            }
        }
        
        // --- Filter and Display API TV Show Results ---
        if ( ! empty( $api_shows ) ) {
            $filtered_api_shows = array_filter($api_shows, function($show) use ($local_tmdb_ids) {
                return !in_array($show['id'], $local_tmdb_ids);
            });

            foreach ( $filtered_api_shows as $show ) {
                 echo '<a href="'.esc_url(home_url('/tv/'.$show['id'].'/'.sanitize_title($show['name']))).'" class="movie-card">';
                 echo '<img src="'.get_tmdb_image_url($show['poster_path']).'" alt="">';
                 echo '<div class="movie-card-info"><h3 class="movie-card-title">'.esc_html($show['name']).'</h3><p class="movie-card-year">TV Show · '.esc_html(substr($show['first_air_date'],0,4)).'</p></div>';
                 echo '</a>';
            }
        }
        ?>
    </div>
<?php else : ?>
    <p>No results found for your search term "<?php echo esc_html( $search_query ); ?>".</p>
<?php endif; ?>

<?php get_footer(); ?>