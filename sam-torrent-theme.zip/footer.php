    </main>
    <footer class="footer">
        <p>© <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.</p>
    </footer>
</div>


<?php wp_footer(); ?>
</body>
</html>
