<?php
/**
 * Template Name: Contact Us
 * @package SamTorrentHub
 */
get_header(); 
?>

<div class="static-page form-page">
    <h1 class="page-title"><?php the_title(); ?></h1>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="entry-content" style="margin-bottom: 2rem;">
            <?php the_content(); ?>
        </div>
    <?php endwhile; endif; ?>

    <?php 
    // Display feedback messages based on the URL parameter
    if ( isset( $_GET['status'] ) ) {
        $status = $_GET['status'];
        if ( $status === 'success' ) {
            echo '<div class="flash success">Thank you for your message!</div>';
        } elseif ( $status === 'email_fail' ) {
            echo '<div class="flash error">Please enter a valid email address.</div>';
        } else {
            echo '<div class="flash error">An error occurred. Please try again.</div>';
        }
    }
    ?>
    
    <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" class="contact-form">
        
        <input type="hidden" name="action" value="sam_contact_form">
        <input type="hidden" name="redirect_url" value="<?php echo esc_url( get_permalink() ); ?>">
        <?php wp_nonce_field( 'submit_contact_form_action', 'contact_form_nonce' ); ?>
        
        <!-- Honeypot -->
        <p style="display:none !important;"><label for="website_url">Website</label><input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off"></p>

        <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="6" required></textarea>
        </div>
        <button type="submit" name="submit_contact_form" class="form-button">Send Message</button>
    </form>
</div>

<?php get_footer(); ?>