<?php
/**
 * The template for displaying all single posts and attachments.
 * This file is highly customized for 'movie' and 'tv_show' post types.
 *
 * @package SamTorrentHub
 */

get_header();

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();

		$current_post_type = get_post_type();

		// --- Main logic for Movie and TV Show CPTs ---
		if ( 'movie' === $current_post_type || 'tv_show' === $current_post_type ) :

			// Automatically check for new torrents on TV show page loads.
			if ( 'tv_show' === $current_post_type ) {
				sam_update_tv_show_torrents_if_needed( get_the_ID() );
			}

			// --- Fetch custom field data ---
			$post_id       = get_the_ID();
			$year          = get_post_meta( $post_id, '_sam_year', true );
			$rating        = get_post_meta( $post_id, '_sam_rating', true );
			$backdrop_path = get_post_meta( $post_id, '_sam_backdrop_path', true );
			$tmdb_id       = get_post_meta( $post_id, '_sam_tmdb_id', true );
			$synopsis      = get_post_meta( $post_id, '_sam_synopsis', true );
			$genres_text   = get_post_meta( $post_id, '_sam_genres_text', true );

			// --- Fetch live data from TMDB API for cast & recommendations ---
			$live_data       = get_live_tmdb_details( $tmdb_id, ( 'tv_show' === $current_post_type ? 'tv' : 'movie' ) );
			$cast            = $live_data['credits']['cast'] ?? null;
			$recommendations = $live_data['recommendations']['results'] ?? null;
			?>

			<?php if ( ! empty( $backdrop_path ) ) : ?>
				<div class="details-banner" style="background-image: url('<?php echo get_tmdb_image_url( $backdrop_path, 'w1280' ); ?>');"></div>
			<?php endif; ?>

			<div class="single-page-layout">
				<div class="single-content-wrapper">

					<!-- Main Details Section (Poster, Title, Synopsis, Cast) -->
					<div class="movie-details-container">
						<div class="details-left">
							<?php if ( has_post_thumbnail() ) {
								the_post_thumbnail( 'large', [ 'class' => 'movie-details-poster' ] );
							} ?>
						</div>
						<div class="details-right">
							<h1><?php the_title(); ?></h1>
							<div class="movie-meta">
								<?php if ( $rating ) : ?><span>⭐ <?php echo esc_html( $rating ); ?></span><?php endif; ?>
								<?php if ( $genres_text ) : ?><span>🎬 <?php echo esc_html( $genres_text ); ?></span><?php endif; ?>
								<?php if ( $year ) : ?><span>🗓️ <?php echo esc_html( $year ); ?></span><?php endif; ?>
							</div>

							<?php if ( $synopsis ) : ?>
								<h2>Synopsis</h2>
								<p><?php echo nl2br( esc_html( $synopsis ) ); ?></p>
							<?php endif; ?>

				<?php if ( ! empty( $cast ) ) : ?>
						<h2>Cast</h2>
						<div class="cast-list">
							<?php
							// First, get all 'actor' terms that are already on this post
							$local_cast_terms = get_the_terms( get_the_ID(), 'actor' );
							$local_cast_links = []; // Create an empty array to store links

							// If we found any terms, map the actor's name to their page link
							if ( $local_cast_terms && ! is_wp_error( $local_cast_terms ) ) {
								foreach ( $local_cast_terms as $term ) {
									$local_cast_links[ $term->name ] = get_term_link( $term );
								}
							}

							// Now, loop through the cast list from the API
							foreach ( array_slice( $cast, 0, 15 ) as $actor ) :
								$actor_name = $actor['name'];

								// Check if this actor exists in our link map
								if ( isset( $local_cast_links[ $actor_name ] ) ) {
									// If yes, print a clickable link
									echo '<a href="' . esc_url( $local_cast_links[ $actor_name ] ) . '" class="cast-member-name">' . esc_html( $actor_name ) . '</a>';
								} else {
									// If no, just print the name as plain text
									echo '<span class="cast-member-name">' . esc_html( $actor_name ) . '</span>';
								}
							endforeach;
							?>
						</div>
					<?php endif; ?>
						</div>
					</div>
					<?php sam_display_ad('ad_single'); ?>

					<!-- =================================================================== -->
					<!-- Download Links Section (This is the block with the new logic)    -->
					<!-- =================================================================== -->
					<?php
					global $sam_theme_options;
					$is_intermediate_page_enabled = isset( $sam_theme_options['enable_intermediate_page'] ) && '1' === $sam_theme_options['enable_intermediate_page'];
					$post_id_for_link             = get_the_ID();

					// --- MOVIE LINKS LOGIC ---
					if ( 'movie' === $current_post_type ) :
						$torrent_titles_str = get_post_meta( $post_id_for_link, '_sam_torrent_titles', true );
						$magnet_links_str   = get_post_meta( $post_id_for_link, '_sam_magnet_links', true );
						$torrent_titles     = ! empty( $torrent_titles_str ) ? explode( "\n", trim( $torrent_titles_str ) ) : [];
						$magnet_links       = ! empty( $magnet_links_str ) ? explode( "\n", trim( $magnet_links_str ) ) : [];
						?>
						<div class="movie-details-container" style="display: block; margin-top: 2rem;">
							<h2>Download Links</h2>
							<?php if ( ! empty( $torrent_titles ) && ! empty( $magnet_links ) ) : ?>
								<div class="torrent-links-container">
									<?php
									$num_torrents = min( count( $torrent_titles ), count( $magnet_links ) );
									for ( $i = 0; $i < $num_torrents; $i++ ) {
										$title  = trim( $torrent_titles[ $i ] );
										$magnet = trim( $magnet_links[ $i ] );
										if ( empty( $title ) || empty( $magnet ) ) { continue; }

										if ( $is_intermediate_page_enabled ) {
											// Render as a link to the download page
											$download_url = home_url( "/download/{$post_id_for_link}/{$i}/" );
											echo '<a href="' . esc_url( $download_url ) . '" class="copy-magnet-button"><span class="quality">' . esc_html( $title ) . '</span></a>';
										} else {
											// Render as a direct-copy button (the old way)
											echo '<button class="copy-magnet-button" data-magnet="' . esc_attr( $magnet ) . '"><span class="quality">' . esc_html( $title ) . '</span></button>';
										}
									}
									?>
								</div>
							<?php else : ?>
								<p>No download links are available for this movie.</p>
							<?php endif; ?>
						</div>
						<?php
						// --- TV SHOW LINKS LOGIC ---
					elseif ( 'tv_show' === $current_post_type ) :
						$raw_torrents_data = get_post_meta( $post_id_for_link, '_sam_torrents_data', true );
						$seasons_data      = sam_parse_tv_torrents_data( $raw_torrents_data );
						$global_link_index = 0; // Crucial for tracking the link index across all seasons
						?>
						<div class="seasons-container">
							<?php if ( ! empty( $seasons_data ) ) : ksort( $seasons_data ); ?>
								<?php foreach ( $seasons_data as $season_num => $season_data ) : ?>
									<div class="season-block">
										<h2 class="season-header">Season <?php echo esc_html( $season_num ); ?></h2>
										<div class="episodes-list">
											<?php if ( ! empty( $season_data['packs'] ) ) : ?>
												<div class="episode-row pack-section">
													<span class="episode-title pack-title">Full Season Packs</span>
													<div class="episode-links">
														<?php foreach ( $season_data['packs'] as $pack ) {
															if ( $is_intermediate_page_enabled ) {
																$download_url = home_url( "/download/{$post_id_for_link}/{$global_link_index}/" );
																echo '<a href="' . esc_url( $download_url ) . '" class="copy-magnet-button pack-button"><span class="quality">' . esc_html( $pack['title'] ) . '</span><span class="size">' . esc_html( $pack['size'] ) . '</span></a>';
															} else {
																echo '<button class="copy-magnet-button pack-button" data-magnet="' . esc_attr( $pack['magnet'] ) . '"><span class="quality">' . esc_html( $pack['title'] ) . '</span><span class="size">' . esc_html( $pack['size'] ) . '</span></button>';
															}
															$global_link_index++;
														} ?>
													</div>
												</div>
											<?php endif; ?>
											<?php if ( ! empty( $season_data['episodes'] ) ) : ksort( $season_data['episodes'] ); ?>
												<?php foreach ( $season_data['episodes'] as $episode_num => $torrents ) : ?>
													<div class="episode-row">
														<span class="episode-title">Episode <?php echo esc_html( $episode_num ); ?></span>
														<div class="episode-links">
															<?php foreach ( $torrents as $torrent ) {
																if ( $is_intermediate_page_enabled ) {
																	$download_url = home_url( "/download/{$post_id_for_link}/{$global_link_index}/" );
																	echo '<a href="' . esc_url( $download_url ) . '" class="copy-magnet-button"><span class="quality">' . esc_html( $torrent['quality'] ) . '</span><span class="size">' . esc_html( $torrent['size'] ) . '</span></a>';
																} else {
																	echo '<button class="copy-magnet-button" data-magnet="' . esc_attr( $torrent['magnet'] ) . '"><span class="quality">' . esc_html( $torrent['quality'] ) . '</span><span class="size">' . esc_html( $torrent['size'] ) . '</span></button>';
																}
																$global_link_index++;
															} ?>
														</div>
													</div>
												<?php endforeach; ?>
											<?php endif; ?>
										</div>
									</div>
								<?php endforeach; ?>
							<?php else : ?>
								<p>No download links are available for this show.</p>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<!-- =================================================================== -->
					<!-- End of Download Links Section                                       -->
					<!-- =================================================================== -->


					<!-- Recommendations Section -->
					<?php if ( ! empty( $recommendations ) ) : ?>
						<div class="related-movies">
							<h2 class="page-title">You Might Also Like</h2>
							<div class="movie-grid">
								<?php
								foreach ( array_slice( $recommendations, 0, 10 ) as $rec ) :
									$rec_post_type_slug = $rec['media_type'] ?? ( 'movie' === $current_post_type ? 'movie' : 'tv' );
									$rec_title          = 'tv' === $rec_post_type_slug ? ( $rec['name'] ?? '' ) : ( $rec['title'] ?? '' );
									if ( empty( $rec_title ) || empty( $rec['id'] ) ) { continue; }
									$item_url = home_url( '/' . $rec_post_type_slug . '/' . $rec['id'] . '/' . sanitize_title( $rec_title ) . '/' );
									?>
									<a href="<?php echo esc_url( $item_url ); ?>" class="movie-card">
										<img src="<?php echo get_tmdb_image_url( $rec['poster_path'] ); ?>" alt="">
										<div class="movie-card-info">
											<h3 class="movie-card-title"><?php echo esc_html( $rec_title ); ?></h3>
											<p class="movie-card-year"><?php echo esc_html( substr( $rec['release_date'] ?? $rec['first_air_date'] ?? '', 0, 4 ) ); ?></p>
										</div>
									</a>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</div> <!-- End .single-content-wrapper -->

				<!-- Sidebar Column -->
				<div class="sidebar-column">
					<?php get_sidebar( 'global' ); ?>
					<?php if ( 'movie' === $current_post_type ) : ?>
						<?php get_sidebar( 'movie' ); ?>
						<?php get_sidebar( 'tv' ); ?>
					<?php else : // 'tv_show' ?>
						<?php get_sidebar( 'tv' ); ?>
						<?php get_sidebar( 'movie' ); ?>
					<?php endif; ?>
					<?php if ( is_active_sidebar( 'sidebar-movie-featured' ) ) : ?>
						<div class="widget-area">
							<?php dynamic_sidebar( 'sidebar-movie-featured' ); ?>
						</div>
					<?php endif; ?>
					<?php if ( is_active_sidebar( 'sidebar-tv-featured' ) ) : ?>
						<div class="widget-area">
							<?php dynamic_sidebar( 'sidebar-tv-featured' ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

		<?php
		// --- Fallback for standard Posts or Pages that aren't movies/shows ---
		else :
			?>
			<article>
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
			<?php
		endif;

	endwhile;
else :
	?>
	<!-- Fallback if no posts were found -->
	<h1 class="page-title">Content Not Found</h1>
	<p>Sorry, the content you were looking for could not be found.</p>
	<?php
endif;

// --- Load comments template ---
if ( comments_open() || get_comments_number() ) :
	comments_template();
endif;

get_footer();
?>