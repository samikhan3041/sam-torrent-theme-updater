<?php
class Sam_Featured_TV_Widget extends WP_Widget {
    public function __construct() {
        // THE FIX IS ON THIS LINE: The extra double-quote after 'sam_featured_tv' has been removed.
        parent::__construct('sam_featured_tv', 'Featured TV Shows', ['description' => 'Displays a list of recent local TV shows.']);
    }
        public function widget($args, $instance) {
        echo $args['before_widget'];
        $title = apply_filters('widget_title', $instance['title']);
        if ($title) { echo $args['before_title'] . $title . $args['after_title']; }
        $query_args = ['post_type' => 'tv_show', 'posts_per_page' => 3, 'orderby' => 'date', 'order' => 'DESC'];
        $featured_query = new WP_Query($query_args);
        if ($featured_query->have_posts()) {
            echo '<ul class="sidebar-featured-list">';
            while ($featured_query->have_posts()) {
                $featured_query->the_post();
                // --- REPLACED get_field() with get_post_meta() ---
                $year = get_post_meta( get_the_ID(), '_sam_year', true );
                echo '<li><a href="' . get_permalink() . '">';
                if (has_post_thumbnail()) {
                    the_post_thumbnail('thumbnail');
                }
                echo '<div class="featured-info"><h5>' . get_the_title() . '</h5><span>TV Show · ' . esc_html($year) . '</span></div>';
                echo '</a></li>';
            }
            echo '</ul>';
        }
        wp_reset_postdata();
        echo $args['after_widget'];
    }
    public function form($instance) {
        $title = $instance['title'] ?? 'Featured TV Shows';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }
}