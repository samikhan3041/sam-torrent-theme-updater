<?php
/**
 * The template for displaying the static front page.
 * It now acts as a loader for our Movies Hub template.
 * @package SamTorrentHub
 */

// Simply include the Movies Hub template.
get_template_part('page-movies');