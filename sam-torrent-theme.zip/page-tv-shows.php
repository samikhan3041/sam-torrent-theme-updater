<?php
/**
 * Template Name: TV Shows Hub
 * @package SamTorrentHub
 */

get_header();


global $sam_theme_options;
$tmdb_api_key = $sam_theme_options['tmdb_api_key'] ?? '';

if (empty($tmdb_api_key)) {
    echo '<h1 class="page-title">Configuration Needed</h1>';
    echo '<p style="text-align:center;">Please go to the <strong>Theme Options</strong> panel in your admin dashboard and enter your TMDB API Key to display TV shows.</p>';
    get_footer();
    return; // Stop the rest of the page from loading
}

/**
 * Helper function to render a TV show section.
 */
function sam_render_tv_hub_section($title, $browse_more_link, $api_params) {
    // --- THE FIX: Call the correct function name 'get_filtered_tmdb_media' ---
    $data = get_filtered_tmdb_media('tv', $api_params);
    $all_shows = $data['items'] ?? [];

    if (empty($all_shows)) {
        return;
    }

    $shows_to_display = array_slice($all_shows, 0, 6);
    ?>
    <section class="hub-section">
        <header class="hub-section-header">
            <h2 class="hub-section-title"><?php echo esc_html($title); ?></h2>
            <a href="<?php echo esc_url($browse_more_link); ?>" class="browse-more-button">Browse More</a>
        </header>
        <div class="movie-grid">
            <?php foreach ($shows_to_display as $show) : ?>
                <a href="<?php echo esc_url(home_url('/tv/' . $show['id'] . '/' . sanitize_title($show['name']))); ?>" class="movie-card">
                    <img src="<?php echo get_tmdb_image_url($show['poster_path']); ?>" alt="<?php echo esc_attr($show['name']); ?>">
                    <div class="movie-card-info">
                        <h3 class="movie-card-title"><?php echo esc_html($show['name']); ?></h3>
                        <p class="movie-card-year"><?php echo esc_html(substr($show['first_air_date'], 0, 4)); ?></p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
}
?>

<h1 class="page-title">Discover TV Shows</h1>

<?php
global $sam_theme_options;
sam_render_tv_hub_section( $sam_theme_options['tv_hub_airing_title'] ?? 'Upcoming Shows (2025)', home_url('/tv/airing/'), ['first_air_date_year' => 2025, 'sort_by' => 'popularity.desc']);
sam_render_tv_hub_section( $sam_theme_options['tv_hub_top_rated_title'] ?? 'Top-Rated Sci-Fi & Fantasy', home_url('/tv/top-rated/'), ['sort_by' => 'popularity.desc', 'with_genres' => '10765', 'with_original_language' => 'en', 'vote_average.gte' => 8, 'vote_count.gte' => 500]);
sam_render_tv_hub_section( $sam_theme_options['tv_hub_netflix_title'] ?? 'Netflix Originals', home_url('/tv/network/netflix/'), ['with_networks' => 213, 'sort_by' => 'popularity.desc']);
sam_render_tv_hub_section( $sam_theme_options['tv_hub_hbo_title'] ?? 'HBO Originals', home_url('/tv/network/hbo/'), ['with_networks' => 49, 'sort_by' => 'popularity.desc']);
sam_render_tv_hub_section( $sam_theme_options['tv_hub_action_title'] ?? 'Action & Adventure', home_url('/tv/genre/sci-fi-action/'), ['with_genres' => '10759', 'sort_by' => 'popularity.desc']);
?>
<?php get_footer(); ?>