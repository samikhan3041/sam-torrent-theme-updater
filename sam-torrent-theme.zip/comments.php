<?php
/**
 * The template for displaying comments
 * @package SamTorrentHub
 */

if ( post_password_required() ) {
    return;
}
?>

<div id="comments" class="comments-area">

    <?php if ( have_comments() ) : ?>
        <h2 class="comments-title">
            <?php
                $comment_count = get_comments_number();
                if ( '1' === $comment_count ) {
                    printf( esc_html__( 'One thought on “%1$s”', 'samtorrenthub' ), '<span>' . get_the_title() . '</span>' );
                } else {
                    printf(
                        esc_html( _nx( '%1$s thought on “%2$s”', '%1$s thoughts on “%2$s”', $comment_count, 'comments title', 'samtorrenthub' ) ),
                        number_format_i18n( $comment_count ),
                        '<span>' . get_the_title() . '</span>'
                    );
                }
            ?>
        </h2>

        <ol class="comment-list">
            <?php
                wp_list_comments( array(
                    'style'      => 'ol',
                    'short_ping' => true,
                    'avatar_size' => 50,
                ) );
            ?>
        </ol>

    <?php endif; ?>

    <?php
        // If comments are closed and there are comments, let's leave a little note.
        if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
    ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'samtorrenthub' ); ?></p>
    <?php endif; ?>

    <?php
        comment_form( array(
            'title_reply'         => esc_html__( 'Leave a Comment', 'samtorrenthub' ),
            'title_reply_to'      => esc_html__( 'Leave a Reply to %s', 'samtorrenthub' ),
            'comment_notes_after' => '',
            'label_submit'        => esc_html__( 'Post Comment', 'samtorrenthub' ),
            'class_submit'        => 'form-button',
        ) );
    ?>

</div><!-- #comments -->